# SENTINEL-X — Plan Index & Read Order

Every file below is a **self-contained build plan for one component**, scaffolding → done.
Read the Master Plan first; build core in order; add non-core anytime after core is demoable.

## UI reference
`../images/*.png` is the final-product UI (dashboard, landing, design-system sheets). Build UI strictly to it, phase by phase. Dashboard = 9 views; see Master Plan §3.

## Start here
- `00_MASTER_PLAN.md` — whole-project context: vision, scope, locked decisions,
  architecture, data model, milestones, demo script, viva prep, risks.

## Core set (build in order — each is a phase = a component)
| File | Component | Depends on | Unlocks |
|---|---|---|---|
| `core/C0_scaffold.md` | Scaffold & skeleton | — | everything |
| `core/C1_indexer.md` | Repository Indexer (AST→IR) | C0 | C2 |
| `core/C2_graph.md` | Security Graph + abstraction | C1 | C3 |
| `core/C3_fact_engine.md` | Security Fact Engine | C2 | C5 |
| `core/C4_knowledge_playbooks.md` | Playbooks (load-by-type) | C0 | C5 |
| `core/C5_agent_runtime.md` | Agent Runtime (LangGraph) | C3, C4 | C6 |
| `core/C6_auth_agent.md` | Auth/Access-Control Agent | C5 | C7 |
| `core/C7_verification_findings.md` | Verification + Finding + Severity | C6 | **demo thread ✅** |
| `core/C8_mongo_attackpath_agents.md` | Dataflow/Mongo + Attack-Path agents | C7 | C9 |
| `core/C9_orchestrator.md` | Orchestrator (supervisor) | C8 | C10 |
| `core/C10_change_intelligence.md` | Change Intelligence | C9 | C11 |
| `core/C11_soc_dashboard.md` | SOC Dashboard (SSE) | C10 | C12 |
| `core/C12_continuous_packaging.md` | Continuous loop + packaging | C11 | ship |

> After **C7** you have a complete end-to-end demo. C8–C12 deepen and productionize.

## Non-core set (independent extensions — any order, after core)
| File | Extension | Tier |
|---|---|---|
| `noncore/N1_vector_rag.md` | Vector/embeddings RAG | High impact |
| `noncore/N2_dep_cve_reachability.md` | Dependency-CVE reachability | High impact |
| `noncore/N9_cvss.md` | CVSS 4.0 scoring | High impact |
| `noncore/N10_report_export.md` | PDF/Markdown report | High impact |
| `noncore/N15_remediation.md` | Remediation guidance (no patching) | High impact |
| `noncore/N3_taint_engine.md` | Taint/dataflow engine | High wow |
| `noncore/N6_runtime_hooks.md` | Runtime instrumentation (live graph) | High wow |
| `noncore/N7_dast_fuzzing.md` | Active DAST / fuzzing | High wow |
| `noncore/N5_business_logic_race.md` | Business-logic & race detection | High wow |
| `noncore/N4_frontend_aware.md` | Frontend-aware analysis | Breadth |
| `noncore/N8_human_in_loop.md` | Human-in-the-loop feedback | Breadth |
| `noncore/N11_mcp_interface.md` | MCP coding-agent interface | Breadth |
| `noncore/N12_model_routing.md` | Model routing / cost control | Breadth |
| `noncore/N13_multi_project.md` | Multi-project management | Breadth |
| `noncore/N14_benchmark.md` | Benchmark vs Semgrep/CodeQL | Breadth |
| `noncore/N16_framework_breadth.md` | NestJS/Fastify/Next.js support | Breadth |

## Unscoped gaps (see Master Plan Appendix — OWASP coverage matrix)
Proposed, no build file yet: N17 misconfiguration checks · N18 dangerous-sink calls (cmd injection/SSRF/path traversal/open redirect) · N19 crypto hygiene · N20 logging & error handling · N21 integrity/deserialization. Also open: finding policy for non-exploitable classes (decide in C7 planning).

## Invariants (true for every file)
1. Agents propose; only the Verification Engine confirms.
2. The verifier touches only the configured sandbox target.
3. Sentinel-X never modifies target code (analysis-only).
4. Consumers use the graph/fact abstraction — never raw Mongo.
5. Core never imports non-core; non-core depends only on published core interfaces.
