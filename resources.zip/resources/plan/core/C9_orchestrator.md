# C9 — Orchestrator (Supervisor)

**Phase:** C9 · **Component:** central coordination of agents + verification requests.
**Purpose:** run agents manually or on triggers, and route all inter-agent and verification
requests through one place. Agents never call each other directly.

## Where it sits
- **Depends on:** C6+C8 (three agents), C7 (verifier).
- **Unlocks:** C10 (change events feed the orchestrator), C11 (UI drives it).

## Objective
A supervisor over the three agents + verifier with three execution modes and a centralized
request protocol.

## Build — scaffolding → done

### Step 1 — Supervisor
- `engine/orchestrator/supervisor.ts`: LangGraph supervisor node that owns the three agents
  and the verifier as callable nodes; tracks the run set + status.

### Step 2 — Execution modes
```ts
runAssessment(projectId)           // all three agents, full pass
runAgent(projectId, agentName)     // one agent on demand
onChange(projectId, changeSet)     // event-triggered: only relevant agents (C10)
// scheduled loop arrives in C12
```
- `engine/orchestrator/run.ts`.

### Step 3 — Request protocol (centralized)
```text
Agent ── InvestigationRequest ──▶ Orchestrator ──▶ target Agent
Agent ── VerificationRequest  ──▶ Orchestrator ──▶ Verifier ──▶ Finding
```
- `engine/orchestrator/requests.ts`: typed requests + routing table. All routing logged to
  `security_events`. Deduplicate identical verification requests within a run.

### Step 4 — Relevance mapping (for onChange)
- Given affected node types, pick agents: routes/middleware/auth → Auth agent;
  inputs/models/queries → Mongo agent; any new finding/observation → Attack-Path agent.

> **C5 as-built note:** each agent run is `runAgent(...)`; the orchestrator supplies `signal` (AbortSignal cancel), may pre-choose `runId` to subscribe before start, and collects `AgentRunResult.verificationRequests` / `.investigationRequests` (also published on bus `events`: `verification.requested`, `investigation.requested`, plus `agent.run.started|finished`). `requestInvestigation` is only accepted for `AgentSpec.investigationTargets`; routing/dedupe/queueing of requests is the orchestrator's job (dedupe verification by `hypothesis.type + subject`). Create one engine per run (fresh graph snapshot). Sum agent budgets for the orchestrator budget.

## Pitfalls
- No agent-to-agent direct calls — enforce by only exposing `requestInvestigation` /
  `requestVerification` tools (from C5) that emit requests the orchestrator routes.
- Keep runs cancellable and budgeted at the orchestrator level too (sum of agent budgets).
- Idempotency: re-running an assessment shouldn't duplicate findings — key on
  `type + affectedNodes`.

## Acceptance / DoD
- `runAssessment` executes all three agents, routes every verification through the
  orchestrator, and produces the full finding set with one command.
- A simulated change (hand-built changeSet) triggers only the relevant agents via `onChange`.

## Handoff
C10 calls `onChange`; C11 exposes `runAssessment`/`runAgent` to the UI; C12 schedules them.
Guarantee: all coordination and verification routing is centralized and logged.
