> **STATUS: ✅ DONE (2026-10-07).** The plan below is the original; **the "As built /
> deviations" section at the end is the source of truth** (Dataflow agent + 3 templates,
> Attack-Path agent + grounding extension + `attachAttackPath`, verified live).

# C8 — Agents 2 & 3: Dataflow/Mongo + Attack-Path

**Phase:** C8 · **Component:** two more specialist agents.
**Purpose:** broaden coverage (injection/data exposure) and compose weaknesses into attack chains.

## Where it sits
- **Depends on:** C5 (runtime), C7 (verification + findings).
- **Unlocks:** C9 (orchestrator coordinates all three).

## Objective
Three agents total, each producing fact-backed hypotheses; the Attack-Path agent turns
verified pieces into labeled attack chains attached to findings.

## Build — scaffolding → done

### Agent 2 — Dataflow / Mongo
**Focus:** NoSQL injection, unsafe user input reaching queries, mass assignment,
sensitive data exposure, dangerous query shapes. Maps to OWASP A05 + parts of A01.

- Instantiate C5 base with `nosql-injection.md` + data-exposure playbooks.
- Investigation: `getDataflow(inputs) → getModelAccess → getSensitiveAssets`; detect:
  - user input reaching a Mongo query object without validation → NoSQL-injection hypothesis;
  - request body spread into `Model.create/update` → mass-assignment hypothesis;
  - sensitive fields returned in a response → data-exposure hypothesis.
- Emit hypotheses + `nosql-injection` verification requests.
- `engine/agents/mongoAgent.ts`.

### Agent 3 — Attack-Path
**Focus:** compositions across observations + findings. Reasons; does not exploit.

- Input: graph + existing observations + confirmed findings.
- Pattern-compose, e.g.:
  ```text
  missing/weak authorization  +  sensitive resource  +  user-controlled id
        →  labeled IDOR attack path
  ```
- Attach `attackPath` (ordered node/edge references + narrative) to the relevant Finding.
  No new verification needed — it reasons over already-verified pieces.
- `engine/agents/attackPathAgent.ts`.

> **C1 as-built note:** data-exposure inputs are in IR: `responses[]` (args as `ValueSrc`, e.g. `res.json(user)`), `mongoOps[].select` (`-password`, `+apiKey`, projections), `.resultVar` (links op result → response var), `models[].fields` (`select:false`). Mass assignment = op `argSources` containing whole `req.body` (`Model.create(req.body)`, `new Model({...req.body})`, `findByIdAndUpdate(id, req.body)`). NoSQLi shape = `queryShape` object keys mapped to `input` sources.

> **C2 as-built note:** data-exposure = `Function EXPOSES Asset` edges (already selection-aware; direct only). Mass-assignment/NoSQLi shapes = `FLOWS_TO Function→Model` edge `props.ops[{op,argSources,queryShape}]`. Attack paths (Attack-Path agent) compose `path()`/`pathDetail()` over Route→PROTECTED_BY/CALLS→ACCESSES/FLOWS_TO/EXPOSES.

> **C3 as-built note:** use `getExposure({asset|route})` (select-aware), `getDataflow({route})` sinks (`queryShape`, `argSources`), and `RouteFact.massAssignment` / `dbOps` for mass-assignment; `getSensitiveAssets` gives `exposedByRoutes`/`touchedByRoutes`.

> **C4 as-built note:** Dataflow/Mongo agent playbooks: `nosql-injection`, `mass-assignment`, `data-exposure`, `secret-exposure` (+ `authorization` reference). Route with `signalsFromRoute` (`query-built-from-input-object`, `mass-assignment`, `exposes-sensitive|credential`) and `signalsFromSecrets`; `registry.getPlaybooksForSignals(signals,{agent:'dataflow'})`. `secret-exposure` was unowned in the original plan — it belongs to this agent. Attack-Path composition rules are NOT a playbook: put them in this agent's prompt.

> **C5 as-built note:** each agent = an `AgentSpec` for `runAgent`. Dataflow/Mongo: `name:'dataflow'`, playbooks `nosql-injection`, `mass-assignment`, `data-exposure`, `secret-exposure`. **Attack-Path** produces no grounded route hypothesis today — the guard supports only `route|jwt|secret` subjects; extend `HypothesisSubject`/`grounding.ts` (e.g. a `chain` subject built from verified findings) or have this agent use `recordObservation` + `attackPath` output; its input is confirmed findings, so it likely runs after C7. `requestInvestigation` is allowed only to `investigationTargets`.

## Pitfalls
- Mongo agent: only propose NoSQLi where input genuinely reaches a query object — verify
  before it becomes a Finding (via C7), never self-confirm.
- Attack-Path must build on *verified* findings/observations, not raw guesses, or the chains
  become fiction. Keep it grounded in the graph.

## Acceptance / DoD
- Mongo agent's NoSQL-injection hypothesis → C7 verifier confirms a seeded injection →
  Finding with evidence.
- Attack-Path agent links "missing authz" + "user-controlled id" + "sensitive Order asset"
  into a labeled attack path attached to the IDOR finding, visible in the evidence chain.

## Handoff
C9 runs all three under a supervisor and centralizes their verification requests.
Guarantee: every agent proposes via the same runtime; only C7 confirms.

---

## As built / deviations (source of truth for later sessions)

**Verified end-to-end for real:** ran the real `dataflowAgent` (via `runAgent`,
`ScriptedProvider`) against the indexed fixture, got genuine `nosql-injection`,
`mass-assignment`, `data-exposure` hypotheses + queued `VerificationRequest`s, drained them
through `verify()` against the **live sandbox** → all three **CONFIRMED** → three real
`critical` `Finding`s persisted. Separately ran the real `attackPathAgent` over two
findings with a guaranteed-connected graph path (`Route:GET /api/orders/:id` →
`Asset:Order.paymentDetails`, 2 hops via the handler's `EXPOSES` edge) and confirmed
`attachAttackPath` wrote a real `attackPath` onto the target `Finding` doc. Full suite:
`npm test -w packages/engine` → **314 passed**, `typecheck`/`lint` clean across all 3
workspaces. Test debris cleaned from the dev Mongo afterward.

### Agent 2 — Dataflow/Mongo: built exactly per plan
`packages/engine/src/agents/dataflow.ts` — `playbooks: ['nosql-injection',
'mass-assignment', 'data-exposure', 'secret-exposure']`, `hypothesisTypes` omitted
(defaults correctly), `investigationTargets: ['auth', 'attack-path']`,
`budget: {maxSteps:28, maxToolCalls:70}`. Three new verifier templates
(`verification/templates/{nosql-injection,mass-assignment,data-exposure}.ts`) extend C7's
template map in `verification/engine.ts`. `secret-exposure` stays template-less (same
deferral as `jwt-security`).

**One real bug found and fixed only by actually running it live** (the whole reason to run
things, not just plan them): `data-exposure.ts` originally picked the *first* `Asset:` node
in `hypothesis.affectedNodes` to check — but `affectedNodes` is alphabetically sorted, so
for the login route it picked `Asset:User.apiKey` (correctly never exposed, `select:false`)
instead of `Asset:User.password` (the actually-leaked field), producing a false REJECTED.
Fixed: the template now checks **every** Asset node named on the hypothesis and CONFIRMS if
any is present in the response.

`mass-assignment.ts` dispatches by exact route (`POST /api/auth/register`,
`PUT /api/orders/:id`, `POST /api/orders` — the last is the negative control, confirmed
REJECTED live since `order.controller.js` sets `user: req.user.id` *after* spreading
`req.body`). `missing-auth.ts`/`bfla.ts` (C7) and the three new templates all substitute
`:id`-style route params with a real seeded id (`substituteId`) before calling — discovered
in C7 that the literal string `":id"` reaches Express fine but then CastErrors in the
handler.

### Agent 3 — Attack-Path: built per the grilled decision, not the original sketch
Confirmed with the user before building: Attack-Path does **not** go through
`proposeHypothesis`/`groundHypothesis`/`requestVerification` — its input is already-CONFIRMED
findings, not live code facts, so forcing it through the hypothesis pipeline would mean
either a trivial self-confirming verifier or hacking the signal gate. Instead:
- `HypothesisSubject` gained a `{kind:'chain', findingIds}` variant for type-level symmetry,
  but `groundHypothesis`/`subjectKindOf` were **not** extended to handle it — a chain
  subject reaching `groundHypothesis` is mechanically rejected (`invalid_argument`). Stated
  as a deliberate scope boundary in code, not an oversight.
- New `FactEngine.getFindings()` (the one place `FactEngine` reads Mongo outside the graph
  snapshot — `models.findings` directly, not through `GraphStore`) and
  `FactEngine.getAttackPath()` (thin wrapper over the already-implemented-but-previously-unexposed
  `GraphStore.pathDetail`). Both registered as `FACT_TOOLS`/`FactToolName` entries.
- New dedicated emit tool `attachAttackPath` (`agents/runtime/tools.ts`, added to
  `EMIT_TOOL_NAMES`) — grounding's mechanical-rejection philosophy applied to this agent:
  refuses (`not_found`/`rejected`/`invalid_evidence`) unless the target finding and every
  finding in the chain are `status:'open'` + `verificationResult:'CONFIRMED'`, and the
  evidence cites a real `getAttackPath` call from this run. Writes via new
  `findings/attachAttackPath.ts` (`findOneAndUpdate`), populating the `attackPath?` field
  C7's `Finding` model left untyped/unused.
- `attackPathAgent` (`agents/attackPath.ts`): no `playbooks` field (confirmed
  `buildSystemPrompt`/`run.ts` degrade gracefully to "no playbook injected" — no crash),
  `hypothesisTypes: []` explicitly (not omitted) so `proposeHypothesis` is a mechanical
  no-op for this agent, `investigationTargets: ['auth','dataflow']`,
  `budget: {maxSteps:16, maxToolCalls:30}`.

### Fallout from adding `getFindings`/`attachAttackPath`: 3 canary tests needed updates
Pre-existing tests asserting "no tool name matches `/finding|confirm|verified|resolve/i`"
(a drift guard, not a design document) legitimately needed new exceptions —
`getFindings` is a sanctioned *read* of already-confirmed findings, `attachAttackPath` only
*attaches a chain to* an already-CONFIRMED finding, neither creates or confirms one. Updated
`test/agents/tools.test.ts` (2 assertions) and `test/agents/runtime.test.ts` (1 assertion)
to exclude these two sanctioned names explicitly rather than loosening the regex.

### Layout
`packages/engine/src/agents/{dataflow,attackPath}.ts`,
`verification/templates/{nosql-injection,mass-assignment,data-exposure}.ts`,
`findings/attachAttackPath.ts`. Extended: `agents/runtime/types.ts` (`chain` subject,
`attachAttackPath` emit name, `getFindings`/`getAttackPath` fact names),
`agents/runtime/grounding.ts` (explicit chain rejection), `agents/runtime/tools.ts`
(`attachAttackPath` tool), `facts/engine.ts`/`facts/tools.ts`/`facts/types.ts`
(`getFindings`, `getAttackPath`, `FindingSummary`/`FindingFilter`/`AttackPathQuery`),
`knowledge/templates.ts` (status strings → `implemented`). Tests:
`test/agents/dataflow.test.ts`, `test/agents/attackPath.e2e.test.ts` (Mongo-gated — the
attach tool reads/writes real `models.findings`), `test/facts/findings.e2e.test.ts`
(Mongo-gated `getFindings`), `getAttackPath` case added to the existing
(non-Mongo) `test/facts/engine.test.ts`, 6 new cases added to
`test/verification/engine.e2e.test.ts`.
