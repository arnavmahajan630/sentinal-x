# C0 — Scaffold & Skeleton

> **STATUS: ✅ DONE (2026-09-24).** Plan below was updated to match what was actually built; see **"As built / deviations"** at the end.

**Phase:** C0 (foundation) · **Component:** monorepo, services, config, LLM abstraction
**Purpose:** a runnable empty system so every later phase has a place to plug in.

## Where it sits
- **Depends on:** nothing.
- **Unlocks:** every phase. C1+ assume the workspaces, Mongo, config, LLM provider,
  and SSE bus created here.

## Objective
`docker compose up` starts Mongo + server + dashboard; `GET /health` is green; the
dashboard shell renders; a scratch call to the LLM provider returns text on Gemini.

## Build — scaffolding → done

### Step 1 — Monorepo
- npm workspaces: `packages/engine`, `apps/server`, `apps/dashboard`.
- Root `tsconfig.base.json`, per-package `tsconfig.json`. ESLint + Prettier.
- Dev runners: `tsx watch` (server), Vite (dashboard).

### Step 2 — Config & env
- `.env.example`:
  ```
  MONGO_URL=mongodb://mongo:27017/sentinelx
  LLM_PROVIDER=gemini            # gemini | deepseek | ollama
  GEMINI_API_KEY=
  DEEPSEEK_API_KEY=
  OLLAMA_URL=http://localhost:11434
  SANDBOX_TARGET_URL=            # set in C7
  SANDBOX_SEED_USERS=./sandbox/seed-users.json
  VERIFICATION_ENABLED=false     # flips true in C7
  ```
- `engine/config.ts`: typed loader (validate with `zod`); never leak secrets to `/api/config`.

### Step 3 — Database
- Mongoose connection singleton.
- `engine/db/collections.ts`: register all collections + indexes now (empty is fine):
  `projects, files, graph_nodes, graph_edges, agent_runs, agent_steps, tool_calls,
  observations, hypotheses, verification_runs, findings, security_events, change_sets,
  security_knowledge`.
- Indexes: `graph_nodes {projectId,type}`, `graph_edges {projectId,type,from}`,
  `findings {projectId,status}`, `agent_steps {runId,ts}`.

### Step 4 — LLM abstraction (lock this interface)
```ts
export interface LlmMessage { role:'system'|'user'|'assistant'|'tool'; content:string; toolCallId?:string }
export interface LlmTool { name:string; description:string; schema:object }  // JSON schema
export interface LlmResponse { text:string; toolCalls:{name:string;args:any;id:string}[]; usage:{inTok:number;outTok:number} }
export interface LlmProvider {
  name:string;
  chat(messages:LlmMessage[], tools?:LlmTool[], opts?:{temperature?:number;maxTokens?:number}):Promise<LlmResponse>;
}
export function getProvider(cfg):LlmProvider;  // demo → Gemini
```
- Adapters wrap LangChain chat models: `ChatGoogleGenerativeAI` (Gemini),
  DeepSeek (OpenAI-compatible base URL), `ChatOllama`. Normalize tool-call output to
  the `LlmResponse` shape so agents never see provider differences.

### Step 5 — Server + SSE bus
- Express app. `GET /health`, `GET /api/config` (safe subset only).
- `engine/bus.ts`: a tiny in-process event bus (EventEmitter) that C5+ publish to and
  the server's SSE endpoints (C11) subscribe to. Define channels now:
  `agent:<runId>`, `events` (global timeline).

### Step 6 — Dashboard shell
- Vite React + TS + Tailwind/shadcn. Sidebar with **9** empty routes (see "As built"): Overview, Attack Surface,
  Security Graph, Findings, Agent Activity, Verification, Changes, Knowledge, Settings. Top bar with a (disabled) "Load project".

### Step 7 — Docker
- `docker-compose.yml`: `mongo`, `server`, `dashboard`. Health-check on server.

## Pitfalls
- Don't hardwire Gemini anywhere but the adapter — everything else calls `LlmProvider`.
- Keep the SSE bus provider-agnostic and JSON-serializable from day one.
- Register collection indexes now; retrofitting after data exists is annoying.

## Acceptance / DoD
- `docker compose up` → all healthy; dashboard loads the shell.
- Scratch: `getProvider(cfg).chat([{role:'user',content:'ping'}])` prints a Gemini reply.
- Swapping `LLM_PROVIDER=ollama` (with Ollama running) works with no code change.

## Handoff
Later phases can rely on: workspaces, typed config, Mongo + all collections/indexes,
`LlmProvider`, and the event bus/channels.

---

## As built / deviations (source of truth for later sessions)

**Verified:** `typecheck`, `lint`, `test` (33 tests) green; `docker compose up --build` → mongo/server healthy,
dashboard serves the shell + SPA fallback; `/health` returns 503 when Mongo is stopped and recovers on restart;
`npm run llm:ping` works on Ollama (`LLM_PROVIDER=ollama OLLAMA_MODEL=qwen2.5:7b-instruct`, no code change); a real tool-call round trip on Ollama normalizes to `LlmResponse.toolCalls` correctly.
**Not verified:** real Gemini call (needs `GEMINI_API_KEY`; adapter is unit-tested + fails clearly without a key).

### Layout
- `engine/x.ts` in this plan == `packages/engine/src/x.ts`. Files: `config.ts`, `bus.ts`, `health.ts`,
  `db/{connection,collections}.ts`, `llm/{types,langchain,index}.ts`, `llm/providers/{gemini,deepseek,ollama}.ts`.
- Engine is consumed as **TS source** (`exports → src/index.ts`); server is bundled with `tsup` (`noExternal` engine).
  Dashboard does **not** import engine.
- Node >=22, ESM, npm workspaces, Vitest 3 (all packages), ESLint 9 flat config, Prettier.

### Config (`.env.example`)
- Added: `PORT`, `GEMINI_MODEL` (default `gemini-2.5-flash`), `DEEPSEEK_MODEL/BASE_URL`, `OLLAMA_MODEL`.
- `MONGO_URL` default is `localhost` (local dev); **docker-compose overrides it to `mongo:27017`** for the server.
- Empty values in `.env` are treated as unset. `publicConfig()` returns only `{llm:{provider,model,configured}, sandbox:{configured,verificationEnabled}}` — no keys/URLs/paths.

### LLM interface
- Locked interface unchanged **except one additive optional field**: `LlmMessage.toolCalls?: {name,args,id}[]`
  (assistant turns must carry their tool calls or tool results can't be replayed to Gemini/OpenAI). Missing tool-call ids get `call_<i>`.
- All providers go through one `LangChainProvider` wrapper; concrete model classes are imported only in `llm/providers/*`.

### Database
- All 14 collections registered with **loose schemas** (`strict:false`, timestamps) — later phases own/tighten shapes.
  Project-scoped collections require `projectId`. Required indexes created via `initCollections()`; extra: `files{projectId,path}`, `security_events{projectId,ts}`, `tool_calls{runId}`.
- `db.test.ts` needs a real Mongo at `MONGO_TEST_URL` (default `mongodb://localhost:27017/sentinelx_test`).

### Event bus
- `EventBus` (typed `EventEmitter` wrapper); message = `{channel, ts, data}`; `publish` JSON-round-trips the payload and throws on non-serializable data.
  Channels: `agent:<runId>` (`agentChannel(runId)`), `events` (`EVENTS_CHANNEL`). Process-wide singleton `bus`. **C5 should publish `{runId,seq,kind,title,detail,ts}` as `data`.**

### Server / health contract
- `GET /health` → `{status:'ok'|'degraded'|'down', ts, components:{engine,sandbox,llm,database}}`, each `{state:'online'|'offline'|'not_configured', detail?}`.
  HTTP **503 only when the database is down**; missing LLM key = `degraded` (200). Sandbox = `not_configured` until `SANDBOX_TARGET_URL` set (C7 should replace this with a real reachability check). LLM pill = "provider configured" only — **never a paid call**.
- Mongo connects in the background so `/health` can report `down` rather than crash boot. `GET /api/config` = `publicConfig`.
- No SSE endpoints yet (C11); nginx already proxies `/api/` with buffering off.

### Dashboard (UI stack + scope decisions)
- Vite + React 19 + TS + **Tailwind v4 + shadcn (dark-first)**. Design tokens sampled from `resources/images` live as CSS vars in `src/index.css`
  (`--sx-*` → Tailwind `bg-surface`, `text-muted`, `text-primary`, …); light theme = same tokens under `[data-theme=light]` (values placeholder, **no toggle built**).
  `components.json` + `lib/utils.ts (cn)` are set up so `npx shadcn add <x>` works; **no shadcn components pre-generated** — add on demand per phase.
- **9 nav routes** (from the final UI images, replacing the original 6): Overview `/`, Attack Surface `/attack-surface`, Security Graph `/graph`,
  Findings `/findings`, Agent Activity `/agents`, Verification `/verification`, Changes `/changes`, Knowledge `/knowledge`, Settings `/settings`.
  "Dev Security" (old name) == **Changes**. Single source of truth: `apps/dashboard/src/nav.ts` (title/tagline/quote/phase per page).
- Shell = Sidebar (logo, 9 nav, "Active Project" placeholder, 4 **live** health pills polling `/health` every 5s) + TopBar (only a disabled "Load project") + `StubPage` (PageHeader + EmptyState per route).
- **Not built in C0 (deliberately):** landing page, project selector/branch/commit/⌘K search/Run Analysis, theme toggle, KPI cards, any charts/tables.

### Docker
- `docker-compose.yml`: `mongo:7` (127.0.0.1:27017, volume, mongosh healthcheck), `server` (:4000, `wget /health` healthcheck, `env_file: .env` optional), `dashboard` (nginx :8080 → proxies `/health`, `/api/`).
  Dashboard has no healthcheck of its own. `sandbox/seed-users.json` is a placeholder (C7 defines the shape).

### Amendments made in C1
- `files` index `{projectId,path}` is now **unique**; `projects` gains `projectId` (unique). `connectDb` sets `ignoreUndefined: true`. Vitest (engine) runs files serially (`fileParallelism:false`) and excludes `**/fixtures/**`; tsc/eslint/prettier exclude `test/fixtures`.
- C2: `graph_nodes`/`graph_edges` now have `id` + `hash` fields, unique `{projectId,id}`, edges also `{projectId,to,type}` (see C2 as-built).
- C4: `PLAYBOOKS_DIR` (optional env, `Config.playbooksDir`); `security_knowledge` has a unique `{type}` index; server image copies `playbooks/`, compose sets `PLAYBOOKS_DIR=/app/playbooks`.
- C5: `LlmChatOptions` gains `toolChoice?: 'auto'|'required'` and `signal?: AbortSignal` (additive); new unique indexes `agent_runs{runId}`, `agent_steps{runId,seq}`, `tool_calls{runId,seq}`, `hypotheses{id}`; LangGraph pinned to 0.4.9 (core 0.3).

### Amendment after the first live Gemini run (C5, 2026-09-27)
- **Gemini adapter is now native REST** (`llm/providers/gemini.ts`, `GeminiProvider`), **not** `@langchain/google-genai` (dependency removed). Reason: Gemini 3.x requires `thoughtSignature` on replayed function-call parts; the LangChain adapter compatible with our pinned core 0.3 drops it → every 2nd agent turn failed with HTTP 400. Signatures travel in the new opaque `LlmToolCall.meta` (kept on the assistant message by the runtime, replayed by the adapter). The adapter also owns Gemini quirks: OpenAPI-subset tool schemas (`sanitizeGeminiSchema`: `const`→`enum`, `exclusiveMinimum`→`minimum`, drops `additionalProperties/default/$schema`), function responses grouped into one user turn, `toolConfig` ANY/AUTO for `toolChoice`.
- **Default `GEMINI_MODEL` = `gemini-3.8-flash`** (`gemini-2.5-flash` returns 404 "no longer available to new users").
- **Now verified live:** `llm:ping` and a 5-call agent run on `gemini-3.8-flash`. DeepSeek/Ollama adapters still LangChain-based; DeepSeek untested live.
