> **STATUS: ✅ DONE (2026-10-07).** The plan below is the original; **the "As built /
> deviations" section at the end is the source of truth** (sandbox, guard, templates,
> Finding model, severity, verified live).

# C7 — Verification Engine + Finding Model + Severity

**Phase:** C7 · **Component:** evidence-based verification, the Finding model, and severity.
**Purpose:** separate AI reasoning from security evidence — prove or reject hypotheses by controlled
exploit **in the sandbox only**, and turn confirmed results into Findings. **This completes the
minimum end-to-end demo.**

## Where it sits
- **Depends on:** C6 (hypotheses). Reuses C0 config + event bus.
- **Unlocks:** the full demo thread; C8+ build on the Finding model.

## Objective
Hypothesis → VerificationRequest → controlled exploit against the sandbox → CONFIRMED /
REJECTED / INCONCLUSIVE (+ evidence) → on CONFIRMED, a `Finding` with severity. Agents can
never mint a Finding.

## Build — scaffolding → done

### Step 1 — Sandbox safety invariant (build FIRST, non-negotiable)
- `engine/verification/guard.ts` wraps ALL outbound HTTP:
  - Read `SANDBOX_TARGET_URL` + seed users from `SANDBOX_SEED_USERS`.
  - **Allowlist:** refuse + log any request whose host ≠ sandbox host.
  - Global kill switch `VERIFICATION_ENABLED`; when false, verification is disabled.
  - Every request/response stored as evidence + a `security_events` entry.
- No verifier code may bypass the guard.

### Step 2 — Sandbox client
- `engine/verification/client.ts`: authenticates as seed users (User A / User B / admin),
  holds their tokens/cookies, issues guarded requests.

### Step 3 — Verification templates (MVP set)
```text
idor:            login as A → request resource owned by B → 200 w/ B's data      = CONFIRMED
missing-auth:    unauthenticated request to a protected route returns data       = CONFIRMED
bfla/authz-bypass: normal user → admin-only endpoint → success                   = CONFIRMED
nosql-injection: operator-injection payload ({"$ne":null}, etc.) → bypass/leak   = CONFIRMED
```
- `engine/verification/templates/*.ts`. Each returns
  `{ result:'CONFIRMED'|'REJECTED'|'INCONCLUSIVE', evidence:{ request, response, expected, actual } }`.

### Step 4 — Verification engine
- `engine/verification/engine.ts`: `verify(request):Promise<VerificationRun>` — picks the
  template from `request.verifierTemplate`, runs it via the guarded client, persists a
  `verification_runs` row with full evidence.

### Step 5 — Finding model
```ts
interface Finding {
  id; projectId; type; severity:Severity; confidence:number;
  status:'open'|'resolved'|'regressed'|'rejected';
  affectedNodes:NodeId[]; evidence; verificationResult; attackPath?;
  agentRun; references:string[]; createdAt; updatedAt;
}
```
- `engine/findings/model.ts` (schema) + `engine/findings/build.ts`
  (`verificationResult → Finding`, only on CONFIRMED).

### Step 6 — Severity scoring (core)
- `engine/findings/severity.ts`:
  `severity = base(type)` escalated by `assetSensitivity`, `exposure(public|authed)`,
  and `verificationStatus(confirmed↑)` → `Critical|High|Medium|Low`. (Full CVSS = N9.)

### Step 7 — Close the loop
- Hypothesis + chosen template → `verify()` → on CONFIRMED, `build()` a Finding + emit to
  the `events` channel. On REJECTED, record it against the hypothesis (no Finding).

> **C0 note:** `/health` (`engine/src/health.ts`) reports Sandbox as `not_configured` when `SANDBOX_TARGET_URL` is unset and `online` if set — replace with a real guarded reachability check here so the Sandbox pill is truthful. `sandbox/seed-users.json` is a placeholder; define its shape here.

> **C2 as-built note:** `Finding.affectedNodes` = graph node ids (stable across rebuilds). `assetSensitivity` for severity = the exposed/touched `Asset` node's `props.tier`/`weight` (credential 1.0, financial 0.9, pii 0.6, pii-broad 0.3); `exposure(public|authed)` = Route `props.protected`/`authEnforcement`.

> **C3 note — OPEN DECISION for C7 planning:** what happens to classes that cannot be proven by an exploit (JWT weak config, hardcoded secrets, data exposure, missing rate limit/CORS)? Options: (a) **static verifier templates** — deterministic checks of graph facts (`getJwtUsage`, `getSecrets`, `getExposure`) minting Findings with `verification:'static'` and lower confidence (keeps "only the Verification Engine mints"), (b) proven-only. C4 playbooks already name templates (`jwt-security`, `secret-exposure`, `authorization`) that must exist or be renamed. See Master Plan Appendix.

> **C4 as-built note:** template contract lives in `knowledge/templates.ts` (`VERIFIER_TEMPLATES`): planned `idor`, `missing-auth`, `bfla` (= playbook `privilege-escalation`), `nosql-injection`; **proposed by C4** `mass-assignment` (send extra privileged field, read back) and `data-exposure` (response contains a sensitive field, value masked in evidence). Playbooks `jwt-security` and `secret-exposure` have `verifierTemplate: null` / `verification: undecided` pending the finding-policy decision. `Severity` = lowercase `critical|high|medium|low|info`; `Finding.references` should come from the playbook's `owasp` (`A01:2025`), `apiTop10` and `cwe[]`; record the playbook `type@version` on the finding's evidence chain.

> **C5 as-built note:** the verifier consumes `VerificationRequest {id, runId, hypothesisId, template, subject:{kind,…}, affectedNodes, requestedAt}` (produced by `requestVerification`, returned in `AgentRunResult.verificationRequests`, stored on the `hypotheses` doc, announced on bus `events` as `verification.requested`) and the stored `Hypothesis {type, subject, evidence[], affectedNodes, signals, playbook:'type@version', verifierTemplate, verification, severityHint, confidence, rationale}`. `Finding.affectedNodes` = the hypothesis' node ids. Only hypotheses whose playbook has a template are ever requested (jwt/secret `undecided`). Persist the verification result back onto the hypothesis (`status`).

## Pitfalls
- The guard is the single most important safety control in the whole system — write it and
  its tests before any template. A verifier that can hit a non-sandbox host is a bug.
- Templates must capture *evidence*, not just a boolean — the Finding's credibility is the evidence.
- Keep `confidence` honest: CONFIRMED-by-exploit is high; INCONCLUSIVE stays a hypothesis.

## Acceptance / DoD
- Auth agent's IDOR hypothesis → verifier logs in as User A, fetches User B's order, gets
  B's data → **CONFIRMED** → a High/Critical Finding with full request/response evidence.
- Point the verifier at a non-sandbox host → **refused + logged**.
- A safe route's hypothesis (if any) → **REJECTED**, no Finding.

## Handoff
C8 agents produce more hypotheses through the same path; C10 re-verifies findings on
change. Guarantee: only verified results become Findings; the sandbox invariant holds.

---

## As built / deviations (source of truth for later sessions)

**Verified end-to-end for real, not just scripted:** indexed the live fixture into the real
dev Mongo, ran the real `authAgent` (via `runAgent`, `ScriptedProvider` standing in for the
LLM) to get a genuine `idor` hypothesis + queued `VerificationRequest`, then
`npm run verify -- <runId>` drove it through the real `guardedFetch` → `SandboxClient` →
`idor` template against the **actually running** docker-compose sandbox →
**CONFIRMED** → a persisted `critical` `Finding` with real request/response evidence
(User A's token, User B's order body). Also verified live: `missing-auth` CONFIRMED on
`GET /api/users/:id`, `bfla` REJECTED on `GET /api/admin/stats` (route is correctly
guarded), and the guard's "unreachable/non-sandbox host → INCONCLUSIVE / refused+logged"
paths. Full suite: `npm test -w packages/engine` → **291 passed** (incl. the new e2e
suites, run against the live sandbox + Mongo), `typecheck`/`lint` clean across all 3
workspaces. Test debris from the manual live-wire check was cleaned from the dev Mongo
afterward.

### Deviations from the original doc (all grilled with the user before building)
1. **No live sandbox existed at all going in** — `vuln-mern`'s own README said "never
   shipped, never run." Built one: `docker-compose.yml` gained `sandbox-mongo` (own Mongo +
   volume), `sandbox-seed` (one-shot, pins fixed Mongo `_id`s for users A/B/admin and two
   orders from `sandbox/seed-users.json` — no runtime write-back needed), and `sandbox`
   (the fixture server via `ts-node --transpile-only`, port `3001:3000`). New
   `sandbox/Dockerfile`, `sandbox/seed.ts`.
2. **Four ops/boot fixes to the fixture, not three** — the original plan anticipated the
   `admin.routes.mjs` require fix, the `plugins/` dir, and `mongoose.connect`. Two more
   turned up only once the app was actually booted (the whole reason it's worth running
   things, not just planning them):
   - `app.js`: `require('./src/users.routes')` needed the same `.default` fix as
     `admin.routes.mjs` (same CJS-requiring-ESM/TS-default-export issue).
   - `src/users.routes.ts`'s `tsconfig.json` needed `"esModuleInterop": true` — without it,
     `import User from '../models/User'` compiled to `undefined.findById(...)`.
   - `plugins/.gitkeep` (added so the directory survives in git) had to be deleted again
     *inside the Docker image* before boot — `dynamic.js` `require()`s every file it finds
     in `plugins/`, including `.gitkeep`.
   - The fixture's own committed `server/package-lock.json` was stale and produced a
     broken `node_modules` (missing `mongoose`'s transitive deps, nondeterministically a
     different one each time) — the Dockerfile deletes it and lets `npm install` resolve
     fresh.
   None of these touch IDOR/auth/JWT logic — purely module-loading and packaging fixes.
3. **`missing-auth`/`bfla` templates substitute `:id`-style params too, not just `idor`** —
   discovered live: sending the literal string `":id"` as a path segment reaches the real
   Express route (Express doesn't know the difference), but then crashes the handler with a
   Mongoose `CastError`. All three templates now call `substituteId` with User B's seeded
   `mongoId` when the route has a param.
4. **`findings`/`verification_runs` collections fleshed out** exactly per the plan's
   `define()` extensions in `db/collections.ts` — no changes from what was planned.
5. Health's sandbox probe (`health.ts`) does gate on `VERIFICATION_ENABLED` via
   `guardedFetch` as planned — when verification is disabled, sandbox reports `offline`
   with that reason in `detail`, not `online`; `not_configured` only when `targetUrl` is
   unset. Does not feed the overall status rollup, as planned.

### Layout
`packages/engine/src/verification/{guard,client,engine}.ts`,
`verification/templates/{types,idor,missing-auth,bfla}.ts`,
`findings/{model,severity,build}.ts`, `scripts/verify.ts` (`npm run verify -- <runId>`),
`sandbox/{Dockerfile,seed.ts,seed-users.json}`. Tests:
`test/verification/{guard,engine}.e2e.test.ts`, `test/findings/{severity,build}.e2e.test.ts`
(Mongo-gated like the rest of the repo's `.e2e.test.ts` files; `engine.e2e.test.ts` is
additionally gated on the live sandbox being reachable, `describe.skipIf`).
