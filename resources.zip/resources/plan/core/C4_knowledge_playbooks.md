# C4 — Security Knowledge Layer (Playbooks)

> **STATUS: ✅ DONE (2026-09-26).** The plan below is the original; **the "As built / deviations" section at the end is the source of truth** (playbook set, front-matter/section contract, signal catalog, tools, sync).

**Phase:** C4 · **Component:** load-by-type security playbooks + loader. No embeddings (that's N1).
**Purpose:** encode human security expertise that guides agents on *how* to investigate and *what* proves a bug.

## Where it sits
- **Depends on:** C0 (config/fs). Independent of the graph; pairs with C3 in C5.
- **Unlocks:** C5/C6 (agents retrieve playbooks by vulnerability type).

## Objective
A `playbooks/` set of markdown files with a fixed structure and a loader that returns the
right playbook(s) for a vulnerability class, including a machine-readable header.

## Build — scaffolding → done

### Step 1 — Author the core playbooks (this is YOUR security judgment)
```
playbooks/idor.md
playbooks/nosql-injection.md
playbooks/jwt-security.md
playbooks/authorization.md
playbooks/privilege-escalation.md
playbooks/secret-exposure.md
playbooks/missing-auth.md
```

### Step 2 — Fixed playbook structure
Each file has YAML front-matter + a fixed body:
```markdown
---
type: idor
verifierTemplate: idor
factQueries: [getRoute, getMiddlewareChain, getDataflow, getModelAccess]
signals: [user-controlled-id-flows-to-model-read, authorization:unknown]
severityBase: high
---
## Threat
## Preconditions
## Signals            # concrete patterns in graph/facts
## Investigation strategy   # ordered fact queries + what to check at each
## Relevant graph relationships
## Verification strategy     # which verifier template proves it, and expected evidence
## Evidence requirements
```

### Step 3 — Loader
```ts
interface Playbook { type:string; verifierTemplate:string; factQueries:string[];
  signals:string[]; severityBase:Severity; body:string }
getPlaybook(type):Playbook
getPlaybooksForSignals(signals:string[]):Playbook[]   // core: simple signal-match, no vectors
listPlaybooks():Playbook[]
```
- `engine/knowledge/loader.ts` parses front-matter (`gray-matter`) + body.
- `engine/knowledge/registry.ts` maps type/signals → playbook. Deterministic.

> **C3 as-built note:** `factQueries` must use exactly the `FACT_TOOLS` names: `getRoutes, getRoute, getMiddlewareChain, getCallGraph, getDataflow, getModelAccess, getDependency, getSensitiveAssets, getUnprotectedRoutes, getRoutesTouchingModel, getAuthorizationGaps, getJwtUsage, getSecrets, getExposure`. Use `getJwtUsage` in `jwt-security`, `getSecrets` in `secret-exposure`, `getExposure` in data-exposure guidance, `getAuthorizationGaps`+`authzEvidence` in `idor`/`authorization`. **Known mismatch:** playbooks `jwt-security`/`secret-exposure`/`authorization` need `verifierTemplate`s C7 does not implement (only `idor`, `missing-auth`, `bfla`, `nosql-injection`) — resolved by the C7 finding-policy decision (static verifier templates vs proven-only).

> **C5 as-built note:** `runAgent` injects `AgentSpec.playbooks` (+ applicable reference playbooks) into the system prompt (sections default: Investigation strategy, False-positive rules, Verification strategy, Evidence requirements) and records `type@version` in `AgentRunResult.playbooks`. The grounding guard reuses the signal catalog: a hypothesis is accepted only if `matchPlaybooks(signalsFor(subject))` contains its type.

## Pitfalls
- Playbooks are the difference between a real tool and a demo. Write them from actual
  exploitation experience — the investigation + verification + evidence sections must be
  concrete enough that an agent can follow them step by step.
- Keep the `factQueries` list aligned with C3's actual method names.
- `verifierTemplate` must match a template that C7 will implement.

## Acceptance / DoD
- `getPlaybook('idor')` returns the IDOR playbook with `verifierTemplate:'idor'`, an
  ordered `factQueries` list, and a body whose Investigation section maps to real C3 calls.
- `getPlaybooksForSignals(['authorization:unknown','user-controlled-id-flows-to-model-read'])`
  returns the IDOR (and authorization) playbooks.

## Handoff
C5 injects the matched playbook into agent context; C6 follows its investigation steps;
C7 uses its `verifierTemplate`. Guarantee: headers are machine-readable and consistent.

---

## As built / deviations (source of truth for later sessions)

**Verified:** `typecheck`, `lint`, `test` (223 engine tests) green. `npm run knowledge -- validate` = consistent; sync is idempotent (9 docs, second run 0 delta); `docker compose build server` ships 9 files in `/app/playbooks`; fixture routing (facts → signals → playbooks) asserted route by route.
**Content authored by Claude (user reviews the `.md` files)** — see `playbooks/*.md`; they are plain files, edit freely (`npm run knowledge -- validate` re-checks consistency).

### Decisions (grilled with user)
1. **9 playbooks** = 8 vulnerability + 1 reference. Auth agent (C6): `idor`, `missing-auth`, `privilege-escalation` (vertical escalation + BFLA), `jwt-security`. Dataflow/Mongo agent (C8): `nosql-injection`, `mass-assignment`, `data-exposure`, `secret-exposure`. Reference (shared): `authorization` (how to read `authorization`/`authzEvidence`; `appliesTo: idor, privilege-escalation, missing-auth`). Attack-Path composition rules stay in C8's prompt.
2. **I authored all content**; tests enforce structure + consistency.
3. **Extras shipped:** knowledge tools, `security_knowledge` sync + versioning, signal catalog + facts→signals routing.

### Layout — `packages/engine/src/knowledge/` (subpath `@sentinelx/engine/knowledge`) + repo-root `playbooks/`
`types.ts` · `schema.ts` (zod front-matter) · `loader.ts` (parse, section split (code-fence aware), hash/version, dir resolution) · `registry.ts` (`KnowledgeRegistry`, `getKnowledge()`, `getPlaybook`, `getPlaybooksForSignals`, `listPlaybooks`, `matchPlaybooks`) · `signals.ts` · `templates.ts` · `validate.ts` · `tools.ts` · `sync.ts` · `errors.ts`. CLI: `npm run knowledge -- list | show <type> [section] | match a,b | signals | validate | sync | route <path> '<route>'`.
**Shared tool layer (C3 amendment):** `src/tools/{registry,errors,suggest}.ts` (subpath `@sentinelx/engine/tools`): `ToolDef<Ctx>`, `ToolResult`, `runTool`, `toLlmToolList`, `combineTools`, `ToolError` (base of `FactError`/`KnowledgeError`). `FACT_TOOLS`/`runFactTool`/`toLlmTools` unchanged for callers. C3 also exports `isWriteOp`.

### Playbook contract
Front-matter (strict zod): `type` (= filename), `title`, `kind: vulnerability|reference`, `agent: auth|dataflow|shared`, `owasp` (`A01:2025`), `apiTop10?`, `cwe[]`, `severityBase: critical|high|medium|low|info` (**lowercase**), `verifierTemplate: string|null`, `verification: dynamic|static|undecided|none`, `factQueries[]`, `signals[]` (any-of), `requires[]` (all-of), `appliesTo[]` (reference), `summary`.
Sections in fixed order — vulnerability: `Threat · Preconditions · Signals · Investigation strategy · False-positive rules · Relevant graph relationships · Verification strategy · Evidence requirements · Remediation guidance` (**adds** *False-positive rules* and *Remediation guidance* — the latter is what N15 reads); reference: `Purpose · Concepts · Reading the facts · Pitfalls`. ≤ 9 000 chars each.
`validatePlaybooks` (used by tests + CLI) enforces: `factQueries` ⊆ `FACT_TOOLS`, each declared query appears in *Investigation strategy* **in declared order** (test), every `getXxx` in the body is declared, ≥2 tools in investigation, signals/requires ⊆ catalog and described in *Signals*, every non-informational catalog signal used, template ∈ `VERIFIER_TEMPLATES` or null, no TODO.

### Matching
Playbook matches iff (`signals` any-of ≥1 present) **and** all `requires` present; rank = matched count + satisfied requires, then `severityBase`, then type; references appended when a matched playbook ∈ their `appliesTo` (`includeReferences:false` to skip); `agent` filter keeps `shared`. Deterministic. Plan DoD: `getPlaybooksForSignals(['authorization:unknown','user-controlled-id-flows-to-model-read'])` → `idor` + `authorization`.

### Signal catalog (`SIGNAL_CATALOG`, pure fns over C3 DTOs)
Route: `authorization:none|unknown|present`(info), `unprotected`(info), `auth-weak`, `user-controlled-id-flows-to-model-read`, `writes-data`(info), `mass-assignment`, `exposes-sensitive`, `exposes-credential`, `query-built-from-input-object` (read/update/delete filter from body/query values), `unprotected-touches-data`, `privileged-path-without-role-check`. JWT: `jwt:hardcoded-secret|literal-fallback|algorithm-none|ignore-expiration|no-expiry|decode-only`. Secrets: `secret:hardcoded|connection-string-credentials|env-file-committed`. `signalsFromRoute/JwtUsage/Secrets`, `collectSignals(engine)`. Note `authorization:none` routes with an id also match `idor` (anonymous object access).

### Verifier templates ↔ C7 (`templates.ts`)
`idor`, `missing-auth`, `bfla` (= `privilege-escalation`), `nosql-injection` = **planned**; `mass-assignment`, `data-exposure` = **proposed by C4** (dynamic sandbox checks; C7 must implement or rename). **`jwt-security` and `secret-exposure` carry `verifierTemplate: null`, `verification: undecided`** — finding policy for non-exploitable classes is still the open C7 decision.

### Tools (`KNOWLEDGE_TOOLS`, `runKnowledgeTool`, `toKnowledgeLlmTools`)
`getPlaybook {type, sections?}` (sections saves tokens) · `getPlaybooksForSignals {signals[], agent?, limit?}` (compact summaries + `matched`, reports `unknownSignals`) · `listPlaybooks {agent?, kind?}` · `getSignalCatalog {}`. Same validation/structured-error shape as fact tools. Merge with `combineTools(FACT_TOOLS, KNOWLEDGE_TOOLS)` (context types differ: pass a combined ctx or adapt per list).

### Persistence, config, packaging
`syncKnowledge(registry)` mirrors metadata + body + `hash`/`version` (`sha1(raw).slice(0,8)`) into `security_knowledge` (unique `{type}`); files remain the source of truth; loader has no Mongo dependency. `PLAYBOOKS_DIR` (optional) → else `<cwd>/playbooks` → else walk up from the module. `apps/server/Dockerfile` copies `playbooks/`; compose sets `PLAYBOOKS_DIR=/app/playbooks`. Agents should record `type@version` per run.

### Fixture routing (asserted in `test/knowledge/routing.test.ts`)
`GET /api/orders/:id` → data-exposure, idor (+authorization) · `PUT /api/orders/:id` → data-exposure, idor, mass-assignment · `POST /api/orders` → data-exposure, mass-assignment · `DELETE /api/orders/:id`, `GET /api/admin/*`, `/api/health`, `/api/profile` → none · `GET /api/orders/mine/:id` → data-exposure · `GET /api/users/:id` and `/api/users/:id/orders` → data-exposure, idor, missing-auth · `POST /api/auth/login` → data-exposure, missing-auth, nosql-injection · `POST /api/auth/register` → data-exposure, mass-assignment, missing-auth. JWT: `sign` → `jwt:hardcoded-secret`, `verify` → `jwt:literal-fallback` → jwt-security; secrets → `connection-string-credentials`, `env-file-committed`, `hardcoded` → secret-exposure.

### Known limits
No model-field facts for non-sensitive privileged fields (`role`, `isAdmin`) → mass-assignment relies on the verifier to prove them; matching is signal-based (no semantic retrieval → N1); playbook prose is not machine-executed (agents follow it; tests only verify tool/signal/template references and order).
