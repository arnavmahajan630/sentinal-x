# C10 — Change Intelligence

**Phase:** C10 · **Component:** targeted re-analysis on code change.
**Purpose:** track security state across edits by re-analyzing only what changed, and transitioning
finding status — the "persistent security model" payoff.

## Where it sits
- **Depends on:** C9 (orchestrator `onChange`), C1/C2 (partial re-index), C7 (re-verify).
- **Unlocks:** C11 Changes view (formerly "Dev Security"), C12 continuous loop.

## Objective
Editing a file updates only the affected subgraph, reruns only relevant agents, re-verifies
touched findings, and moves finding status: `open → resolved`, or `resolved → regressed`.

> **C1 as-built note:** partial re-index is already implemented in C1: `refreshProject(projectId)` (hash-diff, re-extracts only changed files, **re-links everything**, deletes removed files) returns `{changed, changedLinked, removed}`. Use `changedLinked` as the stale set (it includes files whose routes/chains changed because of *another* file, e.g. a removed global middleware). Step 4 here reduces to calling `refreshProject` and mapping those files to graph nodes; C2 must expose a per-file rebuild for `changedLinked`. `reindexFiles` from the original plan is not needed.

> **C2 as-built note:** no per-file graph patching. After `refreshProject` call `buildGraph(projectId)` (diff-apply, deterministic ids): its `changedNodeIds` is the stale set for `onChange` (Route/Function/Middleware/Model/Input nodes → relevant agents; Asset/Secret/Dependency changes → Mongo/Auth agents as appropriate). `removeSubtree` is not needed for change handling.

> **C5 note:** past runs are in `agent_runs`/`hypotheses` (+ LangGraph checkpoints keyed by `runId`) — usable for cross-run memory ("already investigated at graph version X"). Hypothesis identity = `type + subject`; agents re-run on `changedNodeIds` get a fresh `FactEngine`.

## Build — scaffolding → done

### Step 1 — Change detection
- `engine/change/watcher.ts`: `chokidar` watcher on the project root; debounce bursts.
  Fallback: poll `git HEAD` / worktree hash every N seconds (`simple-git`).

### Step 2 — Diff → changed files
- `engine/change/diff.ts`: `simple-git` diff between last-indexed HEAD and current →
  list of changed/added/deleted files.

### Step 3 — Impact analysis
- `engine/change/impact.ts`: map changed files → affected `graph_nodes` (routes,
  functions, models defined in them + their immediate edges) → the "stale set".

### Step 4 — Partial re-index + graph patch
- `engine/change/reindex.ts`: re-run C1 extractors on changed files only; use
  `GraphStore.removeSubtree` + rebuild for affected nodes. Don't rebuild the whole graph.

### Step 5 — Emit change + trigger
- Write a `change_sets` row + `security_events`. Call `orchestrator.onChange(projectId,
  changeSet)` → only relevant agents run on the affected subgraph.

### Step 6 — Finding transitions
- `engine/change/transitions.ts`: for each finding whose `affectedNodes` intersect the
  change, re-verify via C7:
  - CONFIRMED again → stays `open`;
  - REJECTED (fix worked) → `resolved`;
  - previously `resolved` and CONFIRMED again → `regressed`.

## Pitfalls
- Scope the stale set tightly but not too tightly — include callers/callees of changed
  functions so a fix in a helper re-checks routes that use it.
- Deleted files must remove their nodes/edges cleanly (no dangling edges).
- Re-verification must go through the same guarded verifier (sandbox target must be running).

## Acceptance / DoD
- Fix the IDOR route (add an ownership check) + save → only that route's subgraph
  re-indexes → Auth agent reruns on it → verifier re-tests → finding flips to **resolved**.
- Revert the fix → finding flips to **regressed**.
- Editing an unrelated file does **not** trigger the Auth agent.

## Handoff
C11 renders these transitions in the Changes view; C12 runs the check on a schedule.
Guarantee: re-analysis is targeted, and finding status reflects reality.
