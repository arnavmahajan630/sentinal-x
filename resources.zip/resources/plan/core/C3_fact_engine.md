# C3 — Security Fact Engine

> **STATUS: ✅ DONE (2026-09-25).** The plan below is the original; **the "As built / deviations" section at the end is the source of truth** (DTOs, authorization rules, tool registry).

**Phase:** C3 · **Component:** structured query API over the graph — the agent's eyes.
**Purpose:** give agents clean, typed facts instead of raw source, so reasoning is grounded and cheap.

## Where it sits
- **Depends on:** C2 (`GraphStore`).
- **Unlocks:** C5 (these become the agent's tools).

## Objective
A `FactEngine` exposing typed queries that return structured JSON DTOs (never source dumps).
Everything an agent needs to investigate a route, dataflow, or model is one call away.

> **C1 as-built note:** `RouteFact.authorization` derives from C1 `authz` signals of the handler fn (and fns it CALLS, incl. factory-returned middleware via `FnIR.parent`): `ownership-compare`/`user-scoped-query`/`role-check` present → `'present'`; auth middleware in chain but none of those → `'unknown'`; no auth middleware in chain → `'none'`. `authMiddleware` comes from the linked `chain` (entries with `conditional:true` are uncertain → treat as unknown). `sensitiveFields` from `ir.models[].fields`; `select:false` / `select` on ops affect exposure.

> **C2 as-built note:** read the graph only through `MongoGraphStore(projectId)`; ids are deterministic (`Route:GET /api/orders/:id`, `Function:<file>#<name>`, `Model:Order`, `Asset:User.password`). Most facts are precomputed as node props — `getRoute` = `Route` node props + `edgesOf` (PROTECTED_BY ordered by `props.order` → `getMiddlewareChain`; CALLS→handler; FLOWS_TO/ACCESSES `props.ops` → `inputs`/`dbOps`; EXPOSES → exposure). `authorization` (present/unknown/none) is computed **here** from handler Function `props.authz` (+ CALLS closure) and Route `authEnforcement` (`weak` ⇒ unknown, `none` ⇒ none). `getDataflow` = `pathDetail(Input→…, edgeTypes ['FLOWS_TO','CALLS'])` with edge props. `getSensitiveAssets` = `find({type:'Asset'})` + incoming EXPOSES. Use `edgesOf`/`pathDetail` (additive to the locked interface) since ops/order live on edge props. `getUnprotectedRoutes` = `find({type:'Route', props:{protected:false, mounted:true}})`.

## Build — scaffolding → done

### Step 1 — Fact DTOs
```ts
interface RouteFact { id; method; path; protected:boolean; authMiddleware:string[];
  authorization:'present'|'unknown'|'none'; inputs:InputFact[]; dbOps:DbOpFact[];
  sensitiveFields:string[]; handler:string; loc:Loc }
interface MiddlewareFact { name; kind:'auth'|'validation'|'other'; order:number; loc:Loc }
interface DataflowStep { from; to; via; edgeType; loc:Loc }
interface AccessFact { fn; op; model; reachableFromRoute?:string }
interface DependencyFact { name; version; usedBy:string[] }
interface AssetFact { model; field; sensitive:boolean; touchedByRoutes:string[] }
```

### Step 2 — Queries (implement all)
```ts
getRoutes():RouteFact[]
getRoute(routeId):RouteFact
getMiddlewareChain(routeId):MiddlewareFact[]
getCallGraph(fnId):CallNode[]
getDataflow(inputId):DataflowStep[]        // input → sinks (direct in core)
getModelAccess(modelId):AccessFact[]
getDependency(name):DependencyFact
getSensitiveAssets():AssetFact[]
getUnprotectedRoutes():RouteFact[]         // convenience
getRoutesTouchingModel(modelId):RouteFact[]
getAuthorizationGaps():RouteFact[]         // protected but no ownership/role check found
```
- Each method is a thin, well-typed composition over `GraphStore` (`find`, `neighbors`, `path`).

### Step 3 — Determinism & shape
- Facts are stable and JSON-serializable (they become LLM tool outputs in C5).
- Include `loc` everywhere so findings/UI can cite source.
- No prose, no source blobs — structured fields only.

## Pitfalls
- `authorization:'unknown'` vs `'none'`: "unknown" = protected by auth but no visible
  ownership/role check; "none" = no auth at all. Agents treat these very differently.
- Keep queries cheap — agents will call them many times per run; add small in-memory
  memoization per run if needed.

## Acceptance / DoD
- `getRoute('POST /orders/:id')` → `{ protected:true, authMiddleware:['authenticate'],
  authorization:'unknown', inputs:[req.params.id], dbOps:[Order.findById],
  sensitiveFields:['paymentDetails','customerId'] }` — matches source by hand.
- `getUnprotectedRoutes()` and `getAuthorizationGaps()` each return the expected seeded routes.

## Handoff
C5 wraps these as agent tools verbatim. Guarantee: every fact is typed, located, and
derived only through the graph abstraction.

---

## As built / deviations (source of truth for later sessions)

**Verified:** `typecheck`, `lint`, `test` (183 engine tests incl. Mongo parity + shared store-contract suites) green. Fixture ground truth hand-checked; Mongo-backed engine answers **identical** to the in-memory one; after a code fix + rebuild a new engine flips `GET /api/orders/:id` from `unknown` to `present`. `npm run facts` smoke on Sentinel-X's own repo works.
**C3 detects nothing** — it serves facts; agents (C6/C8) reason, C7 proves.

### Decisions (grilled with user)
1. **`authorization`** — `none` = no login at all (chain has no non-conditional authLike middleware **and** no inline JWT verification); `present` = a check that **really blocks**: `user-scoped-query`, `ownership-compare`/`role-check` **with guards** (403/throw/next(err)), searched in handler + callees (CALLS depth ≤2) + chain middleware fns (incl. nested factory fns); `unknown` = logged in but no blocking evidence (unguarded compares, name-only role guard `role-guard-middleware`, **weak auth** caps at unknown, `selfAuthenticated` chain-unprotected routes). Every route returns `authzEvidence[{kind,blocking,where,guards,expr,fn,loc}]` so agents separate IDOR (ownership missing) from BFLA (role missing).
2. **`getAuthorizationGaps()` default = relevant only** (`relevantOnly:true`): mounted + protected + authorization≠present + ≥1 reason among `idParamReachesDb|mutatesData|exposesSensitive|massAssignment`. `{relevantOnly:false}` = plain plan rule. Fixture default = `GET /api/orders/:id`, `POST /api/orders`, `PUT /api/orders/:id`; plain adds `GET /api/profile`.
3. **Extra facts:** `getJwtUsage`, `getSecrets`, `getExposure`. (`getModel`/`getSummary` not built.)
4. **`FACT_TOOLS` registry** (name, description, zod args → JSON schema, `run`) + `runFactTool` → `{ok,data}` | `{ok:false,error{code,message,suggestions[]}}`; **C5 only adapts it**.
5. No new extractors/sinks/middleware-presence facts (OWASP gaps recorded in master Appendix).

### Layout — `packages/engine/src/facts/` (subpath `@sentinelx/engine/facts`)
`types.ts` (DTOs) · `errors.ts` (`FactError` not_found|ambiguous|invalid_argument) · `resolve.ts` (lenient ids, stemmed+edit-distance suggestions) · `snapshot.ts` (in-memory index) · `authorization.ts` (pure) · `engine.ts` (`FactEngine`, `createFactEngine(projectId)`) · `tools.ts` · `index.ts`. Also `graph/memoryStore.ts` (**`InMemoryGraphStore`**). CLI: `npm run facts -- --list` | `npm run facts -- <path> <tool> ['<json>']` (indexes + builds graph, runs one tool).

### Engine model
`new FactEngine(store: GraphStore)` (or `createFactEngine(projectId)` = Mongo). It **snapshots the whole project graph once** via `store.find({})` + `store.edges({})` and answers from memory (no N+1, deterministic). **One instance per agent run; create a new one after `buildGraph`** (`clearCache()` re-snapshots). Route facts are computed once and memoized. `InMemoryGraphStore` + shared **store contract tests** run against both stores.

### Facts (all JSON, `loc` everywhere; ids are human forms: route `'PUT /api/orders/:id'`, fn `file#name`, model `Order`, asset `User.password`)
`getRoutes(filter)→Page<RouteSummary>` (mounted only unless `includeUnmounted`; filters protected/method/pathPrefix/authorization/touchesModel/exposesSensitive/mutates; `Page{total,offset,limit,truncated,items}`) · `getRoute(route)→RouteFact` · `getMiddlewareChain(route)→MiddlewareFact[]` · `getCallGraph(fn,{depth≤6,direction out|in})→CallNode` (≤200 nodes, cycle-marked) · `getDataflow({route,input?}|{inputId})→DataflowFact[]` (`steps[{from,to,via,edgeType,loc}]`, `sinks[{model,op,argSources,queryShape,select,loc}]`) · `getModelAccess(model)→AccessFact[]` · `getDependency(name)` · `getSensitiveAssets({tier?})` · `getUnprotectedRoutes` · `getRoutesTouchingModel` · `getAuthorizationGaps` · `getJwtUsage` · `getSecrets` (masked) · `getExposure({route?,asset?})`.
Lenient ids: `Route:…`/`Function:…` node-id forms, lower-case method, bare path if unique; unknown/ambiguous → `FactError` with ≤5 suggestions.
`RouteFact` = `RouteSummary{id,method,path,fullPath,handler,protected,authEnforcement,authorization,exposesUserId,mutates,massAssignment,exposesSensitive[],models[]}` + `authMiddleware,roleGuards,middleware[],inputs[],dbOps[],sensitiveFields[],exposedSensitive[],authzEvidence[],selfAuthenticated,mounted,dynamic,file,loc`.

### Deviations from the original plan
`sensitiveFields` are model-qualified (`['Order.paymentDetails',…]`); `AccessFact.reachableFromRoute` → `reachableFromRoutes[]`; `MiddlewareFact.kind` adds `'role'`; new fields `authzEvidence`, `exposedSensitive`, `selfAuthenticated`, `massAssignment`, `inputCarrying`; listing queries return pages; `mutates` = write ops in handler closure **or** method ∈ POST/PUT/PATCH/DELETE (gap reason `mutatesData` uses write ops only); tools take `route`/`fn`/`model`/`asset`/`name` args.

### Tool layer (for C5)
`FACT_TOOLS: FactTool[]` (tool name == engine method == playbook `factQueries` entry), `toLlmTools(names?)` → C0 `LlmTool[]` (JSON schema), `runFactTool(engine, name, rawArgs)` (validates; never throws for LLM mistakes; `too_large` guard at 60k chars; read-only — no tool can create/confirm findings).

### Known limits
Snapshot per run (fine to ~50k nodes; not streaming); evidence/closure depths fixed (authz 2, data 3); exposure and dataflow are direct/same-function only (C2); JWT facts only for `jsonwebtoken`/`jose`/`express-jwt` imports; conditional (dynamic-path) middleware is ignored for authorization evidence; no `getFunction`/`getModel`/`getSummary`.

### Amendment made in C4
Tool plumbing was extracted to `src/tools/{registry,errors,suggest}.ts` (`ToolDef`, `runTool`, `toLlmToolList`, `combineTools`, `ToolError`; `FactError extends ToolError`); `FACT_TOOLS`/`runFactTool`/`toLlmTools` keep their API. `isWriteOp` is exported from `facts`. Playbooks `factQueries` are validated against `FACT_TOOLS`.
