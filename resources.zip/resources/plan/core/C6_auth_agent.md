> **STATUS: ✅ CODE-COMPLETE (2026-10-06), live run pending.** The plan below is the
> original; **the "As built / deviations" section at the end is the source of truth.**

# C6 — Agent 1: Auth / Access-Control (flagship)

**Phase:** C6 · **Component:** the flagship security agent.
**Purpose:** detect access-control weaknesses — IDOR/BOLA, BFLA/function-level auth, missing auth,
privilege escalation, JWT/authentication flaws — as evidence-backed **hypotheses**.

## Where it sits
- **Depends on:** C5 (runtime), C3 (facts), C4 (access-control playbooks).
- **Unlocks:** C7 (its hypotheses drive the verifier and the first confirmed finding).

## Objective
Running the Auth agent on the vulnerable app yields a ranked list of hypotheses, each with
the graph evidence behind it, including at least the seeded IDOR — and *few false positives*
on the seeded safe routes.

> **C1 as-built note:** the "visible ownership check" signal is C1's `authz` IR (`ownership-compare` with `guards`, `user-scoped-query`, `role-check`, `operands`). A compare without `guards` may be a non-enforcing check — treat guarded ones as strong evidence. Fixture safe routes: `DELETE /api/orders/:id` (ownership-compare, 403) and `GET /api/orders/mine/:id` (user-scoped-query); seeded IDOR: `GET /api/orders/:id`.

> **C3 as-built note:** start from `getAuthorizationGaps()` (relevant-only default) then `getRoute` → `authzEvidence`. `authorization:'present'` already means a *blocking* check exists (scoped query / guarded ownership or role check) — do **not** flag those (fixture: `DELETE /api/orders/:id`, `GET /api/orders/mine/:id`, admin routes). `unknown` + `exposesUserId` ⇒ IDOR candidate; `none` ⇒ missing-auth; role evidence missing on privileged routes ⇒ BFLA. JWT: `getJwtUsage()` flags (`hardcoded-secret`, `literal-fallback`, `algorithm-none`, `ignoreExpiration`, `decode-only`) and routes using `verify`.

> **C4 as-built note:** the agent's playbooks are `idor`, `missing-auth`, `privilege-escalation` (BFLA + vertical), `jwt-security` (+ the `authorization` reference). Route them from facts: `signalsFromRoute(await engine.getRoute(id))` → `registry.getPlaybooksForSignals(signals,{agent:'auth'})`; JWT via `signalsFromJwtUsage`. Fixture: `GET/PUT /api/orders/:id` → idor; `GET /api/users/:id(/orders)` → idor + missing-auth; `DELETE /api/orders/:id`, `GET /api/orders/mine/:id`, admin routes → no access-control playbook (blocking checks present). Public-by-design routes (login/register) are handled by the missing-auth *False-positive rules*. Playbook `severityBase` and `owasp`/`cwe` feed hypotheses/findings.

> **C5 as-built note:** implement the agent as an `AgentSpec` for `runAgent` (`@sentinelx/engine/agents`): `name:'auth'`, `systemPrompt`, `playbooks:['idor','missing-auth','privilege-escalation','jwt-security']` (the `authorization` reference is attached automatically), `hypothesisTypes` (default = auth playbooks), `investigationTargets:['dataflow']`. Do not write the loop. **Hypotheses are guarded**: the model calls `proposeHypothesis {type, subject:{kind:'route'|'jwt',…}, evidence:[call numbers], rationale, confidence}`; the runtime rejects anything the facts/signals don't support (so the ownership-check false positive is enforced mechanically) and fills `affectedNodes`, `playbook@version`, `verifierTemplate`. Per-route work: give the run a focused goal/context (e.g. the candidate routes from `getAuthorizationGaps`) and raise `budget.maxSteps` accordingly (default 12 LLM turns). Test with `ScriptedProvider` (exported by `@sentinelx/engine/agents`).

## Build — scaffolding → done

### Step 1 — Goal & prompt
- Instantiate the C5 base with a system prompt anchored on `idor.md`, `authorization.md`,
  `privilege-escalation.md`, `missing-auth.md`, `jwt-security.md`.
- Goal: "For each route, determine whether access control is enforced correctly; where it
  isn't, propose a hypothesis with evidence and the right verification template."

### Step 2 — Investigation loop (guided by playbook `factQueries`)
```text
for each route:
  getRoute → getMiddlewareChain → getDataflow(inputs) → getModelAccess
  detect signals:
    - authorization:'none'                        → missing-auth hypothesis
    - user-controlled id FLOWS_TO model read/write
        AND authorization:'unknown'               → IDOR/BOLA hypothesis
    - normal-user route hitting admin-only model/op → BFLA hypothesis
    - jwt.verify missing/weak/secret in code       → auth/JWT hypothesis
```

### Step 3 — Hypothesis emission
```ts
proposeHypothesis({
  type:'idor', route:'POST /orders/:id',
  evidence:{ inputs, dataflow, middlewareChain, modelAccess, sensitiveFields },
  suggestedVerifier:'idor', rationale
})
```

### Step 4 — Ranking
- Rank hypotheses by `assetSensitivity × exposure` (public > authed) so the verifier and
  dashboard surface the scariest first.

### Step 5 — Verification handoff
- For each hypothesis, `requestVerification(...)` (queued; routed by C9 once it exists —
  in C7 it may call the verifier directly to close the loop).

## Pitfalls
- **False positives kill credibility.** A route with a visible ownership check
  (`resource.ownerId === req.user.id`) must NOT be flagged — teach the signal logic to
  detect ownership/role checks in the handler via the call/dataflow facts.
- Distinguish authentication (who you are) from authorization (what you may do) — most
  IDORs are authenticated-but-unauthorized.
- Keep the agent grounded in facts; if it "believes" a bug with no supporting fact, drop it.

## Acceptance / DoD
- On the seeded app, flags the known IDOR on `/orders/:id` and the other access-control
  bugs with correct evidence.
- Does **not** flag the seeded safe route that has a proper ownership check.
- Every hypothesis carries a `suggestedVerifier` matching a C7 template.

## Handoff
C7 consumes these hypotheses to run controlled exploits and mint Findings. Guarantee:
each hypothesis is fact-backed, ranked, and carries a verifier template.

---

## As built / deviations (source of truth for later sessions)

**Verified:** `typecheck` and the full `packages/engine/test/agents` + `test/knowledge`
suites green (78 tests, excluding the 2 pre-existing Mongo-dependent e2e suites that need
a local MongoDB — unrelated to C6). The new `test/agents/auth.test.ts` (8 tests,
`ScriptedProvider`) proves, end-to-end through the real runtime and fixture graph: the
seeded IDOR (`GET /api/orders/:id`) grounds with `playbook: 'idor@…'`,
`verifierTemplate: 'idor'`, correct `affectedNodes`; all three DoD "must not flag" routes
(`DELETE /api/orders/:id`, `GET /api/orders/mine/:id`, `GET /api/admin/stats`) are
mechanically rejected by `groundHypothesis` with `not_supported_by_facts`; a JWT hypothesis
on the hardcoded-secret `sign` call grounds with `verifierTemplate: null` (documented gap,
not fixed — see below); `requestVerification` queuing works and is optional.
**Not yet done: the live-model smoke run** (Gemini, small `--max-steps`, per the C5
precedent) — deferred by user choice (see "Open" below), so real-model judgment on the
login/register false-positive exclusion is unverified beyond the prompt-content regression
check in `auth.test.ts`.

### Scope — no C5/C4/C3/C1 changes
C6 is almost entirely a new `AgentSpec`; the grounding guard, playbook registry, facts, and
authz IR are all consumed as-is from C5/C4/C3/C1. Confirmed via a C4 registry check that all
four vulnerability playbooks (`idor`, `missing-auth`, `privilege-escalation`,
`jwt-security`) declare `agent: auth`, so `hypothesisTypes` is **left unset** on
`authAgent` — it defaults correctly via `run.ts`'s `playbook.agent === spec.name` filter.
`mass-assignment` is `agent: dataflow`, so `POST /api/orders` is naturally out of scope
with no prompt-level exclusion needed.

### `packages/engine/src/agents/auth.ts` (new)
Plain `AgentSpec` const, sibling of `demo.ts`. `playbooks: ['idor', 'missing-auth',
'privilege-escalation', 'jwt-security']` (the `authorization` reference auto-attaches via
`withReferences`); `hypothesisTypes` omitted (see above); `investigationTargets:
['dataflow']` (whitelists the tool-level check only — no dataflow agent exists yet);
`budget: {maxSteps: 24, maxToolCalls: 60}` (vs demo's 16/40 — not yet tuned against a live
run). **Decision (grilled with user): the system prompt does not restate playbook content.**
`buildSystemPrompt()` already injects every playbook's own "False-positive rules" section
verbatim (confirmed: `missing-auth.md` carries the literal `/login`/`/register` "public by
design" exclusion), so `auth.ts`'s prompt only adds persona, cross-playbook investigation
order (`getAuthorizationGaps` first, a separate `getJwtUsage` pass, then
authn-vs-authz framing), to avoid two copies of the same rule drifting apart. Exported from
`agents/index.ts` next to `demoAgent`.

### Known gap inherited from C4, not fixed here
`playbooks/jwt-security.md` has `verifierTemplate: null` (`verification: undecided`). Any
`jwt-security` hypothesis grounds successfully but can never be queued via
`requestVerification` ("No verifier template for jwt-security yet"). This conflicts with
this file's own DoD line ("every hypothesis carries a verifier template") for JWT
specifically — `test/agents/auth.test.ts`'s JWT case asserts and documents this rather than
hiding it. C7 or a C4 follow-up must decide the jwt-security verifier before that DoD line
is fully true.

### CLI — `packages/engine/scripts/agent.ts`
Added `--agent demo|auth` (default `demo`) selecting from a small local map; default `goal`
per agent (auth: the Step 1 goal text above). No other CLI changes.

### Tests — `packages/engine/test/agents/auth.test.ts` (new, 8 tests)
Reuses `test/agents/helpers.ts`'s `harness()`, overriding `agent: authAgent`. Covers: seeded
IDOR grounding; mechanical FP rejection on all three DoD safe routes (parametrized);
JWT grounding with the documented `verifierTemplate: null` gap; optional
`requestVerification` queuing; a registry assertion pinning `hypothesisTypes`'s default
derivation (`listPlaybooks({kind:'vulnerability', agent:'auth'})` ==
`['idor','jwt-security','missing-auth','privilege-escalation']`, so a future playbook
`agent:` edit breaks a test here instead of silently changing scope); a prompt-content
regression check that the `missing-auth` playbook's injected False-positive rules text
names auth endpoints as public by design. **Honest limitation, stated in the test file's
header comment:** `ScriptedProvider` can prove which tool calls succeed/fail, but cannot
prove a real model *chooses not to* call a tool — so the login/register exclusion is only
regression-tested at the prompt-content level here, not proven as model behavior. That
requires the live run below.

### Open
**Live Gemini smoke run not yet performed** — user deferred it this session (requires their
`GEMINI_API_KEY` inline, never written to file, per the project's standing preference).
Before calling C6 fully done (parity with C5's "verified live" bar), run:
```
GEMINI_API_KEY=… npm run agent -w packages/engine -- \
  packages/engine/test/fixtures/vuln-mern --agent auth --max-steps 20
```
and confirm: `idor` hypothesis on `GET /api/orders/:id` (and ideally the two `/api/users/…`
routes); no hypothesis on `DELETE /api/orders/:id`, `GET /api/orders/mine/:id`, or either
admin route; no `missing-auth` on `POST /api/auth/login`/`register`; run ends `completed`
within budget (tune `maxSteps` down if it finishes with room to spare). Also still open from
C7 planning: finding policy for non-exploitable OWASP classes (carried over from C5/C6
planning notes).
