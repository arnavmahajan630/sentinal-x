# C11 — SOC Dashboard

**Phase:** C11 · **Component:** the operator UI, wired to live SSE. Build last, on stable APIs.
**Purpose:** present the whole system — posture, attack surface, graph, findings, live agent
activity, dev-security — as a SOC-style console. This is the demo surface.

## Where it sits
- **Depends on:** C0 (shell, event bus), C2/C3 (graph/facts), C7 (findings), C9 (run controls),
  C10 (transitions).
- **Unlocks:** C12 packaging.

## Objective
A React dashboard with **nine** views streaming live over SSE, plus controls to load a project
and run assessments/agents. **C0 already built the shell** (Sidebar w/ 9 routes + live health pills, TopBar, `StubPage`s, design tokens) — C11 fills page bodies; it does not rebuild the shell. UI must match `resources/images/*`.

## Build — scaffolding → done

### Step 1 — Server APIs
- REST reads: `/api/findings`, `/api/graph?filter=`, `/api/routes`, `/api/runs`,
  `/api/events`, `/api/project`.
- Controls: `POST /api/project/load`, `POST /api/assess`, `POST /api/agent/:name`,
  `POST /api/watch`.
- SSE: `/api/stream/agent/:runId` (subscribes to bus `agent:<runId>`),
  `/api/stream/events` (global timeline). `apps/server/sse/*`.

### Step 2 — Client data layer
- React Query for REST; `apps/dashboard/hooks/useSse.ts` wraps `EventSource` for live streams.

### Step 3 — Views
```text
Overview        posture score, open findings, critical/high counts,
                attack-surface size, agent activity, recent events
Attack Surface  routes table + trust boundaries (protected/unprotected, sensitive)
Security Graph  interactive FILTERED subgraph (React Flow / Cytoscape) — by route or finding
Findings        list → drill-down: full evidence chain (obs→hyp→verify→finding) + severity + attack path
Agent Activity  LIVE SSE: agent, status, hypotheses, tool calls, duration, result
Verification    (image: verifcaiton.png) runs list + flow/evidence/raw logs for each verification run (C7 data)
Changes         (was "Dev Security") latest commit, security changes, new/resolved/regressed findings (from C10)
Knowledge       playbooks browser (C4 data)
Settings        engine / LLM provider / sandbox config (from /api/config)
```
Page files are currently stubs at `apps/dashboard/src/pages/StubPage.tsx`; routes/titles/taglines live in `apps/dashboard/src/nav.ts`.
- `apps/dashboard/src/pages/{Overview,AttackSurface,Graph,Findings,AgentActivity,Verification,Changes,Knowledge,Settings}.tsx` (replace `StubPage` per route in `App.tsx`).
- Also build here (deferred from C0): landing page as a **single-project loader** (Add Local Repository live; Connect GitHub / Add from Git URL rendered disabled until N13), top-bar project selector/branch/commit/⌘K/Run Analysis, light-theme toggle.
- Non-core UI seen in images (CVSS score, Fix Recommendation tab, Export, GitHub source) only render when N9/N15/N10/N13 register.

> **C5 as-built note:** the SSE payload is exactly the persisted step `{runId, seq, kind, title, detail, ts}`; on (re)connect replay with `getRunSteps(runId, afterSeq)` then subscribe to bus `agent:<runId>`. Kinds: `run.started · llm · tool.call · tool.result · observation · hypothesis · hypothesis.rejected · verification.requested · investigation.requested · nudge · budget.exhausted · error · run.finished`; `detail` has structured data (tool args, `preview`, hypothesis/verification objects).

### Step 4 — Live agent view (the demo centerpiece)
- Agent Activity subscribes to `agent:<runId>` and renders steps as they stream:
  observation → hypothesis → verification request → result. Make it readable at a glance.

### Step 5 — Graph rendering
- Never render the whole graph. Render a subgraph filtered by the selected route or finding.

## Pitfalls
- SSE reconnection: handle drops/retries in `useSse` so a long agent run doesn't stall the UI.
- Keep the evidence chain drill-down concrete — show the actual request/response captured by C7.
- Performance: paginate findings/events; lazy-load graph subgraphs.

## Acceptance / DoD
- From the UI: "Load project" → "Run assessment" → Agent Activity streams steps live →
  a confirmed finding appears in Findings with a clickable evidence chain → Graph view
  highlights the affected route.
- Fix code (C10) → Changes view shows the finding transition to resolved in near real time.

## Handoff
C12 packages this behind `docker compose up` and adds the scheduler + CLI. Guarantee:
every core capability is observable and operable from the dashboard.
