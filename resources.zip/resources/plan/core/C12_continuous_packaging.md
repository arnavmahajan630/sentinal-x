# C12 — Continuous Operation & Packaging

**Phase:** C12 · **Component:** the steady-state loop, packaging, and CLI.
**Purpose:** make Sentinel-X behave like the product — a self-running loop, one-command startup,
and a headless CLI. Ship-ready.

## Where it sits
- **Depends on:** all core phases (C0–C11).
- **Unlocks:** the final Definition-of-Done demo; nothing depends on this.

## Objective
`docker compose up` brings the whole system online; a scheduler keeps it live with honest
idle state; a CLI drives it without the UI.

## Build — scaffolding → done

### Step 1 — Scheduler loop
- `apps/server/scheduler.ts`:
  ```text
  Change check ─▶ (changed?) ─▶ graph update ─▶ orchestrator ─▶ agents
        ─▶ verification ─▶ findings ─▶ dashboard (events)
  ```
- When nothing changed, emit an honest idle status, e.g.
  `"No changes. Current state: 12 open, 0 critical, 2 high"`. Never fake activity.

### Step 2 — CLI
- `apps/server/cli.ts` (`commander`):
  ```
  sentinel load <path>     # index + build graph
  sentinel scan            # run full assessment
  sentinel watch           # start change intelligence loop
  sentinel findings        # print current findings + severity
  ```

### Step 3 — Packaging
- Finalize `docker-compose.yml` (mongo + server + dashboard), `.env` handling,
  and a `sandbox/` compose for the target app + `seed-users.json`.
- `README.md`: setup, run, and the demo script (from the Master Plan).

### Step 4 — Demo hardening
- Pre-seed the target's known bugs; script a rehearsed run; keep a recorded backup demo in
  case of live LLM flakiness. Set `LLM_PROVIDER=gemini` for the demo.

> **C4 note:** the `playbooks/` directory must ship with the server image (already copied by `apps/server/Dockerfile`; compose sets `PLAYBOOKS_DIR`). Run `syncKnowledge` on boot so `security_knowledge` and the Knowledge view reflect the files.

## Pitfalls
- Idle honesty matters — the product should be useful and truthful when nothing is happening.
- Don't let the scheduler and a manual UI run collide on the same project — single active run per project.
- Make first-run setup foolproof (`.env.example` → `.env`, seed users documented).

## Acceptance / DoD (mirrors Master Plan)
Fresh machine: clone → set `.env` → `docker compose up` → open dashboard → load the
vulnerable app → run assessment → get confirmed findings → edit code → watch the loop
re-verify and transition the finding. The full loop runs end-to-end, unattended between steps:
```text
load → index → graph → baseline → agent flags IDOR → dataflow traced →
verified in sandbox → finding in SOC → dev fixes → change detected →
agent reruns → finding re-verified → resolved
```

## Handoff
This is the shippable core. Non-core modules (`noncore/N*.md`) attach from here without
touching any core internals.
