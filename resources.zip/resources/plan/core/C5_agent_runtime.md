# C5 — Agent Runtime (LangGraph base)

> **STATUS: ✅ DONE (2026-09-27).** The plan below is the original; **the "As built / deviations" section at the end is the source of truth** (loop, tools, grounding guard, budgets, events, persistence, API).

**Phase:** C5 · **Component:** generic agent runtime (before any specific agent).
**Purpose:** a reusable loop that reasons with tools (Fact API + playbooks), streams every step
over SSE, remembers across steps, and stops within a budget — and can never confirm a finding.

## Where it sits
- **Depends on:** C3 (facts as tools), C4 (playbooks), C0 (LLM provider, event bus).
- **Unlocks:** C6, C8 (specialist agents instantiate this base).

## Objective
Instantiate an agent with a goal + toolset; it plans, calls tools, observes, reflects,
loops or concludes; emits `agent_run/agent_step/tool_call/observation/hypothesis`; enforces
max-steps + token budget; persists a replayable trace.

## Build — scaffolding → done

### Step 1 — Tools (wrap C3 + C4)
- `engine/agents/runtime/tools.ts`: expose each Fact Engine query and
  `getPlaybook/getPlaybooksForSignals` as a **LangGraph tool** with a typed JSON schema.
- Add emit tools: `recordObservation`, `proposeHypothesis`,
  `requestVerification` (queues a VerificationRequest — routed in C9).
- **No `createFinding` tool exists.** Type-level guarantee that agents can't confirm.

### Step 2 — Base agent graph
```text
plan ──▶ act(tool) ──▶ observe ──▶ reflect ──▶ (loop | conclude)
```
- `engine/agents/runtime/baseAgent.ts`: LangGraph state machine bound to `LlmProvider`.
- State: `{ goal, context, playbooks, scratch, observations, hypotheses, budget }`.
- Checkpointer (Step 4) persists state each transition.

### Step 3 — Budget & termination
- `engine/agents/runtime/types.ts`: `Budget { maxSteps; maxTokens }`,
  `TerminationCriteria { onBudgetExhausted:'inconclusive' }`.
- Hard stop when either cap hits; emit a terminal step; mark the run `inconclusive` if no
  conclusion reached. Track token usage from `LlmResponse.usage`.

### Step 4 — Memory
- `engine/agents/runtime/memory.ts`: Mongo-backed checkpointer keyed by `runId`.
  Enables replay and (later) cross-run memory in C10.

### Step 5 — Event emission (→ SSE)
- `engine/agents/runtime/events.ts`: every step/tool_call/observation/hypothesis is
  persisted **and** published to bus channel `agent:<runId>` in a UI-ready JSON shape:
  `{ runId, seq, kind, title, detail, ts }`.

### Step 6 — Run lifecycle
- `runAgent({goal, tools, playbooks, budget}):Promise<AgentRunResult>` creates the
  `agent_runs` row, drives the graph, returns `{ runId, observations, hypotheses, status }`.

> **C0 note:** `LlmMessage` has an additive optional `toolCalls` (assistant turns) so tool results replay correctly; the event bus (`engine/src/bus.ts`) is `publish(channel, data)` → `{channel, ts, data}` — put `{runId,seq,kind,title,detail,ts}` in `data`; use `agentChannel(runId)`.

> **C2 as-built note:** tool inputs/outputs should use graph node ids (`Route:…`, `Function:…`, `Asset:…`) so `affectedNodes`, observations and hypotheses reference stable ids across rebuilds.

> **C3 as-built note:** do not hand-write fact tools. Import `FACT_TOOLS`/`toLlmTools()`/`runFactTool` from `@sentinelx/engine/facts` and adapt them to LangGraph tools; `runFactTool` validates args and returns `{ok:true,data}` or `{ok:false,error{code,message,suggestions}}` — feed errors back to the model (do not throw). Create one `FactEngine`/`createFactEngine(projectId)` **per run** (snapshot; new instance after `buildGraph`). Tool names equal playbook `factQueries`.

> **C4 as-built note:** playbooks come from `getKnowledge()` (`@sentinelx/engine/knowledge`). Two ways to use them: (1) **inject** — compute signals with `collectSignals(engine)` / `signalsFromRoute(routeFact)` and put `registry.getPlaybooksForSignals(signals, {agent})` (or `getPlaybook(type)` sections) into the agent context; (2) **tools** — `KNOWLEDGE_TOOLS` (`getPlaybook {type, sections?}`, `getPlaybooksForSignals`, `listPlaybooks`, `getSignalCatalog`) alongside `FACT_TOOLS`; both use the shared `ToolDef`/`runTool` from `@sentinelx/engine/tools` (contexts differ: FactEngine vs KnowledgeRegistry). Record `type@version` of every playbook used in the run trace. Playbook prose already tells the agent which `getXxx` tools to call in order.

## Pitfalls
- Force tool use over free-form prose — the agent should *query facts*, not imagine them.
- Cap `maxSteps` low first (e.g. 12) and raise as behavior stabilizes; runaway loops burn tokens.
- Keep events small and serializable; the dashboard renders them live.
- Gemini vs DeepSeek tool-calling differ — the C0 adapter must normalize, so the runtime
  is provider-agnostic.

## Acceptance / DoD
- A trivial agent ("list unprotected routes and explain the risk of each") calls
  `getUnprotectedRoutes`, streams steps over `agent:<runId>`, stops within budget, and
  persists a full trace you can replay from Mongo.
- Switching provider to Ollama runs the same agent with no code change.

## Handoff
C6/C8 supply only a goal, system prompt, and signal logic — the loop, tools, budget,
memory, and streaming are done here. Guarantee: agents can propose but never confirm.

---

## As built / deviations (source of truth for later sessions)

**Verified:** `typecheck`, `lint`, `test` (261 engine tests incl. Mongo e2e: real index → graph → FactEngine(Mongo) → agent → Mongo trace + LangGraph checkpoints) green. The full loop is exercised with `ScriptedProvider` (deterministic). **Live run (Gemini `gemini-3.8-flash`, `--max-steps 8`, user-supplied key via env, not stored):** the demo agent called `getUnprotectedRoutes`, `getRoute`×4, recorded 4 observations (marked login/register **safe: public by design**, exactly as the missing-auth playbook's false-positive rule says), proposed 2 grounded `missing-auth` hypotheses (`GET /api/users/:id`, `GET /api/users/:id/orders`; affectedNodes derived by the runtime), and `finish`ed — 5 LLM calls, 12 tool calls, ~44k tokens, 42 s, status `completed`. The live run found two real bugs fixed in C0's Gemini path (schema keywords Gemini rejects; missing thought signatures — see C0 amendment). **Still unverified:** local Ollama (laptop too small), DeepSeek, and behaviour on the harder Auth/Dataflow prompts (C6/C8).

### Decisions (grilled with user)
1. **LangGraph pinned: `@langchain/langgraph@0.4.9` + `@langchain/core` 0.3 + `@langchain/langgraph-checkpoint-mongodb@0.1.1`.** 1.x needs core 1.x (would force reworking C0 adapters) → "upgrade the LangChain stack to 1.x" is a separate later task.
2. **Tool-calling loop + `finish` tool**, one LLM call per step. Plan = first step; reflect = runtime nudges (no tool call → reminder + `toolChoice:'required'`, max 2, then `inconclusive: no_tool_use`; budget warning at the last 2 steps). No separate plan/reflect LLM phases.
3. **Grounding guard on `proposeHypothesis`** (details below).

### Layout — `packages/engine/src/agents/` (subpath `@sentinelx/engine/agents`)
`runtime/types.ts` · `context.ts` (truncate/prune) · `prompt.ts` · `grounding.ts` · `tools.ts` (`RunCtx`, emit tools, `buildAgentTools`) · `events.ts` (`RunEmitter`) · `store.ts` + `memoryStore.ts` + `mongoStore.ts` · `memory.ts` (checkpointer) · `baseAgent.ts` (`buildAgentGraph`, StateGraph) · `run.ts` (`runAgent`, `getRunSteps`) · `testing.ts` (`ScriptedProvider`, `call`, `calls`, `say`, `finishCall`) · `../demo.ts` (`demoAgent`). CLI: `npm run agent -- <path> [--goal] [--provider] [--model] [--max-steps]` (index + graph + streamed demo run).
C0 additions: `LlmChatOptions.toolChoice?: 'auto'|'required'` and `signal?: AbortSignal`; `LangChainProvider` gets a provider-specific "required" value (`'any'` Gemini, `'required'` DeepSeek/OpenAI; Ollama can't force → ignored) with fallback to a normal call if rejected. `ToolErrorCode` extended: `not_allowed | not_supported_by_facts | invalid_evidence | duplicate | rejected`.

### Loop (LangGraph `StateGraph`; LLM still called through `LlmProvider`)
`agent` node (stop check → prune context → LLM call with retries → emit `llm` step) ⇄ `tools` node (run each tool call via shared `runTool`, number it, persist, feed `{"call":N,"ok",data|error}` back) → END on `finish`, budget, cancel or provider failure. Graph state is minimal (`messages, steps, nudges, forceTool, done`); observations/hypotheses/requests live in `RunCtx` (persisted to Mongo), not in the checkpoint. Tool errors are **fed back to the model**, never thrown; the run never throws for model/tool/provider problems (status `failed|inconclusive|cancelled` + persisted trace).

### Tools an agent gets (`AgentToolName` literal union — no `createFinding`/confirm member; a test also forbids names matching `/finding|confirm|verified|resolve/`)
All 14 `FACT_TOOLS` + 4 `KNOWLEDGE_TOOLS` + 5 emit tools: `recordObservation {kind: fact|safe|note, text, evidence?}` · `proposeHypothesis {type, subject, evidence[], rationale, confidence}` · `requestVerification {hypothesisId}` · `requestInvestigation {agent, question, refs?}` (queue only; allowed targets = `AgentSpec.investigationTargets`) · `finish {outcome: findings|none|inconclusive, summary}`. Every tool result the model sees is `{"call": N, ...}` (per-run call number = citable evidence).

### Grounding guard (`grounding.ts`, pure; all facts via the FactEngine)
A hypothesis is accepted only if: (a) `type` is a **vulnerability playbook** in `AgentSpec.hypothesisTypes` (default = playbooks whose `agent` equals the agent name) and the subject kind matches the playbook (route / jwt / secret); (b) the subject **exists** (unknown → `not_found` + suggestions); (c) **signal gate** — the playbook actually matches the subject's fact signals (`signalsFromRoute|JwtUsage|Secrets` + `matchPlaybooks`), so playbook false-positive rules are enforced mechanically (e.g. `idor` on a route with a blocking ownership check → `not_supported_by_facts: authorization:present`); (d) `evidence` cites ≥1 successful **fact-tool** call of this run and ≥1 is about the subject; (e) not a duplicate `type+subject` in the run. On success the **runtime fills** `affectedNodes` (route: Route + handler Function + Models + Assets; jwt: Function + Routes; secret: Secret + users), `signals`, `playbook: "type@version"`, `verifierTemplate`/`verification` from the playbook, `severityHint = severityBase`. Rejections emit `hypothesis.rejected` and go back to the agent.
`requestVerification` only for a hypothesis of this run whose playbook has a non-null `verifierTemplate` (jwt-security/secret-exposure = `undecided` → refused with that message — C7 decision still open); deduped; creates `VerificationRequest {id, runId, hypothesisId, template, subject, affectedNodes, requestedAt}`.

### Budget / termination
`Budget {maxSteps=12 (LLM turns), maxTokens=60_000, maxToolCalls=40, timeoutMs=300_000, llmTimeoutMs=90_000}` checked **before** each LLM call. Exhaustion → `budget.exhausted` step, status `inconclusive` with `reason` (`budget:steps|tokens|toolCalls|timeout`), partial observations/hypotheses kept. `AbortSignal` → `cancelled`. Provider errors retried 2× (default backoff 1 s/3 s; `retryDelaysMs` overridable) then `failed` (`error` persisted). Usage from `LlmResponse.usage`, estimated (chars/4) when a provider reports none. Context control: tool output shown to the LLM capped at 8 000 chars (full copy in `tool_calls`); when the conversation exceeds 60 000 chars older tool results become `[omitted: <tool> …]` (last 6 kept).

### API
`runAgent({projectId, agent: AgentSpec, goal, context?, budget?, playbooks?, provider?, engine?, registry?, store?, checkpointer?, bus?, signal?, runId?, retryDelaysMs?}) → AgentRunResult {runId, status, reason?, summary, outcome?, observations, hypotheses, verificationRequests, investigationRequests, usage, steps, playbooks['idor@…'], durationMs, error?}`. Defaults: `getProvider(loadConfig())`, `createFactEngine(projectId)` (**new per run** — facts are a snapshot), `getKnowledge(cfg.playbooksDir)`, `MongoRunStore` + Mongo checkpointer (memory checkpointer when a custom `store` is passed). `AgentSpec {name, systemPrompt, playbooks?, sections?, hypothesisTypes?, investigationTargets?, budget?}`. Injected playbooks automatically get the applicable **reference** playbook (`authorization`); default injected sections: *Investigation strategy, False-positive rules, Verification strategy, Evidence requirements* (reference: *Concepts, Reading the facts, Pitfalls*). `runId` option lets callers subscribe to `agent:<runId>` before the run starts.

### Events & persistence
Every step is persisted (`agent_steps`, unique `{runId,seq}`, contiguous from 1) **and** published on bus `agent:<runId>` as `{runId, seq, kind, title, detail, ts}`; kinds: `run.started · llm · tool.call · tool.result · observation · hypothesis · hypothesis.rejected · verification.requested · investigation.requested · nudge · budget.exhausted · error · run.finished`. Global timeline (`events`) gets `agent.run.started|finished`, `hypothesis.proposed`, `verification.requested`, `investigation.requested`. `getRunSteps(runId, afterSeq)` = SSE replay. Collections: `agent_runs` (unique `runId`), `agent_steps`, `tool_calls` (unique `{runId,seq}`, full output), `observations`, `hypotheses` (unique `id`, holds `verificationRequest`); **LangGraph checkpoints** in `agent_checkpoints` / `agent_checkpoint_writes` (`thread_id = runId`; created by the saver, not in the original 14). No `resumeAgent` yet (checkpoints exist for inspection/replay and later cross-run memory).

### Known limits
One real model verified (Gemini flash, small demo goal); `AbortSignal.any` needs Node ≥ 20; prompts are generic (C6/C8 add role prompts); one run = one agent (parallelism/queueing is C9); hypothesis subjects limited to route/jwt/secret; grounding covers facts, not source text (by design).
