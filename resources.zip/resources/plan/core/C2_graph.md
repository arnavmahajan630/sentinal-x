# C2 — Application Security Graph

> **STATUS: ✅ DONE (2026-09-25).** The plan below is the original; **the "As built / deviations" section at the end is the source of truth** (id scheme, node/edge catalog with props, diff-apply build, GraphStore additions).

**Phase:** C2 · **Component:** graph nodes/edges + graph-query abstraction
**Purpose:** turn IR into a queryable security graph, behind an abstraction so storage is swappable.

## Where it sits
- **Depends on:** C1 (IR in `files`).
- **Unlocks:** C3 (Fact Engine reads the graph via the abstraction).

## Objective
`buildGraph(projectId)` populates `graph_nodes` + `graph_edges`; a `GraphStore`
abstraction answers all traversal/lookup queries so nothing downstream touches Mongo.

> **C1 as-built note:** C2 consumes `loadProjectIR(projectId)` (from `@sentinelx/engine/indexer`): `routes` already carry `fullPath`, ordered `chain` (with origin + resolved fnIds), `handlerFnId`, `mounted`; `files[].linked.calls` are resolved (`fn|model|external`); `linked.opModels[i]` gives the model per `ir.mongoOps[i]` (**ignore ops with null model**). **Do not re-resolve mounts/paths/imports here.** Model nodes come from `ir.models[]` (fields → `props.sensitive` via name heuristics; `select:false`, `ref` available). `traits`/`authz`/`responses`/`secrets`/`jwtOps`/`envReads`/`deps` are raw facts to attach to nodes; auth-like classification of middleware is C2's policy (use `traits` + name). Input nodes from `ir.inputs` (`boundTo` aliases); FLOWS_TO from `mongoOps.argSources`/`queryShape` (direct only). `<file>#<module>` fnId = top-level code (attach to File).

## Build — scaffolding → done

### Step 1 — Types
```text
Node types:  Project · File · Function · Route · Middleware · Input ·
             Model · Database · Dependency · Secret · ExternalService · Asset
Edge types:  CONTAINS · CALLS · FLOWS_TO · PROTECTED_BY · ACCESSES ·
             DEPENDS_ON · EXPOSES · USES
```
```ts
interface Node { id:NodeId; projectId:string; type:NodeType; key:string; props:Record<string,any>; loc?:Loc }
interface Edge { id:string; projectId:string; type:EdgeType; from:NodeId; to:NodeId; props?:Record<string,any> }
```

### Step 2 — GraphStore abstraction (lock this interface)
```ts
export interface GraphStore {
  addNode(n:NodeInput):Promise<NodeId>;
  addEdge(e:EdgeInput):Promise<void>;
  node(id:NodeId):Promise<Node>;
  neighbors(id:NodeId, edgeType?:EdgeType, dir?:'out'|'in'):Promise<Node[]>;
  find(q:NodeQuery):Promise<Node[]>;                 // by type/props
  path(from:NodeId, to:NodeId, edgeTypes?:EdgeType[]):Promise<Node[]|null>;
  removeSubtree(nodeIds:NodeId[]):Promise<void>;     // used by C10 partial re-index
}
```
- `MongoGraphStore` implements it over `graph_nodes`/`graph_edges`. `path()` = bounded BFS.

### Step 3 — Builder (IR → graph)
- `engine/graph/build.ts`:
  - `Project CONTAINS File CONTAINS Function/Route/Model`.
  - `Route PROTECTED_BY Middleware` (from ordered middleware; auth-like names tagged).
  - `Route CALLS Function`, `Function CALLS Function` (from IR call graph).
  - `Function ACCESSES Model`, `Model ACCESSES Database`.
  - `Input FLOWS_TO <sink>` — **direct, same-scope only** in core (deep taint = N3).
  - `File DEPENDS_ON Dependency`; `Function USES Secret`; `Function USES ExternalService`.

### Step 4 — Sensitivity & protection heuristics
- `engine/graph/sensitivity.ts`:
  - Mark `Asset`/`Model` fields sensitive: `password, token, paymentDetails, ssn,
    customerId, email, apiKey…` → `props.sensitive=true`.
  - Mark routes `protected=true` if an auth-like middleware is in the chain, else `false`.
  - Mark routes `exposesUserId=true` if a `req.params`/`req.query` id `FLOWS_TO` a model op.

### Step 5 — Wire builder to run after index
- `buildGraph(projectId)` clears prior graph for the project, then rebuilds. Emit a
  `security_events` entry ("graph built: N nodes, M edges").

## Pitfalls
- Callee resolution across files/imports is the hard part — resolve what you can,
  leave unresolved calls as `CALLS`-to-`external` rather than dropping edges.
- Keep FLOWS_TO honest: only edges you can actually justify from the AST. Over-claiming
  here creates agent false positives downstream.
- Store `loc` on nodes so the dashboard and findings can point at real source lines.

## Acceptance / DoD
- Query `POST /orders/:id` → returns its `PROTECTED_BY` middleware, its `CALLS` chain to
  `updateOrder → Order.findById`, and `ACCESSES → MongoDB`.
- `find({type:'Route', props:{protected:false}})` returns exactly the unprotected routes.
- `path(inputNode, modelNode, ['FLOWS_TO','CALLS'])` finds the user-id→DB path for the IDOR route.

## Handoff
C3 builds structured facts purely through `GraphStore`. Guarantee: routes carry
`protected`/`exposesUserId`; assets carry `sensitive`; edges are justified.

---

## As built / deviations (source of truth for later sessions)

**Verified:** `typecheck`, `lint`, `test` (130 engine tests incl. DB-backed store/incremental suites) green. Fixture graph = **102 nodes / 228 edges** (16 Route, 2 Model, 1 Database, …); DoD queries hand-checked (see Ground truth). Rebuild with no change → **zero delta**; edit/removal → only affected ids change, **no dangling edges** (asserted after every mutation).
Smoke on Sentinel-X's own repo: builds (72 files, 2 routes, 53 deps), no crash. **Not verified:** very large graphs (>50k nodes), `pathDetail` performance on dense graphs.

### Decisions (grilled with user)
1. **Pure model + diff-apply** (replaces "clear + rebuild" and C10's per-file `removeSubtree`): `buildGraphModel(input)` is a pure fn → full desired `{nodes,edges}`; `buildGraph(projectId)` diffs by content hash and upserts/deletes only the delta. Same path for first build and every C10 patch; deterministic ids keep `Finding.affectedNodes` valid across rebuilds.
2. **`Function EXPOSES Asset`** edges (direct: fn returns a var bound to a *document-returning* op result — find/findOne/findById*/findOneAnd*/create/insertMany/new — minus `.select('-x')`/projection/`select:false` unless `+x`).
3. **Sensitivity tiers** (all chosen): `credential`(1.0) `financial`(0.9) `pii`(0.6) `pii-broad`(0.3; bare `name` only on person-like models).
4. **External calls** → `Function CALLS Dependency(pkg)` (node builtins flagged) + package→service table (`graph/services.ts`) → `ExternalService` + `Function USES ExternalService`.
5. **`protected` is evidence-based** with `authEnforcement: enforcing|weak|none`.
6. **FLOWS_TO = Input→Function→Model**; DB ops live on **edge props**, not nodes.
7. **File nodes**: indexed, unparsed(`unparsed:true`), client-recorded, config; tests/skipped excluded. **Explicit `buildGraph`** + `npm run graph`; `indexProject` unchanged.

### Layout — `packages/engine/src/graph/` (subpath `@sentinelx/engine/graph`)
`types.ts` · `ids.ts` · `sensitivity.ts` · `services.ts` · `policy.ts` (pure policy) · `model.ts` (pure builder) · `store.ts` (interface) · `mongoStore.ts` · `build.ts` (`buildGraph`, `applyGraphModel`) · `util.ts` (stable hash) · `index.ts`.
`loadProjectIR` moved to `indexer/load.ts` (no ts-morph import; still re-exported from `@sentinelx/engine/indexer`). `SECRET_NAME_RE` is **duplicated** in `graph/sensitivity.ts` (not imported from the indexer, to avoid loading ts-morph).

### API
```ts
buildGraph(projectId): Promise<{projectId,nodes,edges,added,changed,removed:{nodes,edges},changedNodeIds:NodeId[],durationMs}>   // requires indexProject first; emits security_events 'graph.built' + bus 'events' {kind:'graph.built'}
buildGraphModel({projectId, project?, files: FileRow[]}): {nodes,edges}     // pure, deterministic order; asserts no dangling edges
applyGraphModel(projectId, model)                                            // diff-apply used by buildGraph
new MongoGraphStore(projectId): GraphStore                                    // bound to one project
```
`changedNodeIds` = added/changed/removed nodes + surviving endpoints of changed edges → **the C10 stale set** (map to agents via node types). CLI: `npm run graph -- <path> [--dump summary|routes|route <id>|find <Type>|path <from> <to>|json]` (indexes then builds).

### GraphStore (locked core kept; additive marked +)
`addNode/addEdge` (upsert) · `node(id)→Node|null` · `neighbors(id, edgeType?, dir='out')` · `find({type|type[], key, keyPrefix, props:{'a.b':v}, limit})` · `path(from,to,edgeTypes?,maxDepth=8)` (directed, batched BFS) · `removeSubtree(ids)` (nodes + incident edges) · **+ `edgesOf(id,{type?,dir?})`, `edges({type,from,to,props,limit})`, `pathDetail(...)→{nodes,edges}`, `stats()`**. Edge props carry ops/order/exposure, so C3 needs `edgesOf`/`pathDetail`. No cache (C3 memoizes per run).

### Ids (deterministic, project-scoped by field)
`NodeId="<Type>:<key>"`, edge id `"<TYPE>|<from>|<to>"` (same-pair edges merge; details in props). Keys: `Project:<pid>` · `File:<path>` · `Function:<file>#<name>` · `Route:<METHOD fullPath>` · `Middleware:<fnId>[(<args>)]` / `Middleware:ext:<factory>` · `Input:<fnId>:req.<src>.<path>` · `Model:<name>` (`Model:collection:<x>` raw driver) · `Asset:<Model>.<field>` · `Database:mongodb` · `Dependency:<pkg>` · `Secret:env:<NAME>` / `Secret:hardcoded:<file>:<line>` · `ExternalService:<Name>`.
Mongo: `graph_nodes`/`graph_edges` docs `{projectId,id,type,key|from,to,props,loc?,hash}`; unique `{projectId,id}`; `{projectId,type}`; edges `{projectId,type,from}` + `{projectId,to,type}`.

### Node catalog (props)
- **Route**: `method,path,fullPath,file,handler(fnId),mounted,dynamic?,protected,authEnforcement,authMiddleware[],roleGuards[{name,args?}],exposesUserId,exposesSensitive[AssetIds],inputs[canonical]`. (`authorization` present/unknown/none is **C3's**, derived from Function `authz`.)
- **Middleware**: `name,external,factory?,args?,kind auth|role|validation|other,authLike,enforcing,roleGuard,reason,traits?,fnId?` (traits/authz unioned over the fn **and nested fns** so factory-returned middleware is judged correctly).
- **Function**: `name,file,params,async,traits,isHandler,isMiddleware,parent?,authz[{kind,expr,operands?,guards?,line}],responses[{method,status,args,line}],jwtOps[],envReads[]`. `<file>#<module>` code attaches to the **File** instead.
- **Input**: `fnId,source,path,canonical,boundTo[],userControlled`. **Model**: `name,schema(bool),varName,fields[],files[]`. **Asset**: `model,field,tier,weight,type,selectFalse,ref?` (child skipped if parent is an Asset).
- **Database**: `engine,drivers[],connectionEnv[],credentialsInUrl`. **Dependency**: `name,builtin,declared,installed?,range?,dev?,declaredIn[]`. **Secret**: env → `name,source:'env',hasDefault,definedIn?,preview,len`; hardcoded → `name,source:'code',kind,preview,len,usage?,fallbackFor?` (**never raw values**). **ExternalService**: `name,category,packages[]`. **File**: `path,kind,lang,status,unparsed?,flags?,envKeys?`.

### Edge catalog
CONTAINS: Project→File, File→Function/Route/Model/Secret, Model→Asset · EXPOSES: Project→Route (mounted only), **Function→Asset** `{via,model,var,select?,opLine,responses[]}` · CALLS: Route→handler `{wrapper?}`, Function→Function `{count}`, Function→Dependency `{module,calls[{name,line}]}`, **Middleware→Function** `{role:'implementation'}` (no new edge type) · PROTECTED_BY: Route→Middleware for **every** chain entry `{order,orders[],origin,mountPath?,conditional?,authLike,kind}` · ACCESSES: Function→Model `{ops[{op,argSources,queryShape?,select?,chain?,resultVar?,instance?,line,col}]}`, Model→Database · FLOWS_TO: Input→Function `{boundTo}`, Function→Model (only ops whose args carry input) `{ops[{op,argSources,queryShape?,line}]}` · DEPENDS_ON: File→Dependency `{modules[],line}` and `package.json`→declared deps `{declared,range,installed,dev}` · USES: Function→Secret `{via[]}`, Function→ExternalService `{package}`, **File→ExternalService** (import-level, added beyond the plan so service nodes are reachable).
Module-level ops/secrets/env reads hang off the File (no Function node).

### Policy (all in `policy.ts`/`sensitivity.ts`, easy to extend)
`authLike` = `callsJwtVerify` | `readsAuthHeader+setsReqUser` | known external lib (`passport.authenticate`, `expressjwt`, clerk…) | strong internal name (`authenticate|requireAuth|protect|verifyToken…`; **`authorize` is a role guard, not auth**). `enforcing` needs `sendsAuthError` (or known lib). `weak` = authLike without rejection evidence (e.g. `optionalAuth`) → C3 treats as `unknown`. Middleware with dynamic-path `use()` (`conditional`) never counts as protection. `exposesUserId` = params/query/body input with id-like path (`id,_id,*Id,*_id,user,owner,account,uid`) flows to a model op in the handler. Classification lists live in `sensitivity.ts` (credential/financial/pii/pii-broad).

### Ground truth (fixture) — see `packages/engine/test/graph/*.test.ts`
Open mounted routes: `GET /api/health, /api/v1/ping, /api/v2/ping, /api/users/:id, /api/users/:id/orders`, `POST /api/auth/login, /register`; `GET /` (dynamic.js) `mounted:false`. `PUT /api/orders/:id`: PROTECTED_BY `[cors, express.json, authenticate]`, CALLS `updateOrder`, `path(Input:…#updateOrder:req.params.id, Model:Order, [FLOWS_TO,CALLS])` = `[input, updateOrder, Order]`. `GET /api/admin/stats`: `authenticate` + `requireRole('admin')` (roleGuard), exposes nothing (returns a count). Exposure: `GET /api/orders/:id` → `Order.customerId, Order.paymentDetails`; `GET /api/users/:id/orders` → only `customerId` (`.select('-paymentDetails')`); `GET /api/users/:id` → `User.email, User.password` (not `apiKey`, `select:false`). Only external service: `HTTP Client` used by the React client (`axios`).

### Known limits
Exposure is direct-only (`res.json(order.user)`, transformed/mapped results, helper-function returns are not linked → N3); FLOWS_TO same-function only; single-writer assumption (no transactions; unordered bulk writes); Mongo/mongoose only (`Database:mongodb`); `Function CALLS` from callbacks stay on the callback fn (C1 limit).

### Amendment made in C3
`graph/memoryStore.ts` adds **`InMemoryGraphStore`** (same semantics as `MongoGraphStore`; shared store contract tests run on both).
