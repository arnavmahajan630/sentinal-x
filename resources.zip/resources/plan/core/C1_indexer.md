# C1 — Repository Indexer (AST → IR)

> **STATUS: ✅ DONE (2026-09-24).** The plan below is the original; **the "As built / deviations" section at the end is the source of truth** (IR shape, linker, extra extractors, API).

**Phase:** C1 · **Component:** AST-based repository indexer
**Purpose:** turn a MERN repo into a normalized intermediate representation (IR). No graph yet.

## Where it sits
- **Depends on:** C0 (workspaces, Mongo, config).
- **Unlocks:** C2 (the graph is built from this IR).

## Objective
`indexProject('/path/to/app')` parses every relevant file and persists structured IR to
the `files` collection — routes, functions, inputs, Mongoose/JWT ops, deps, env reads —
each with precise source locations.

## Build — scaffolding → done

### Step 1 — Discovery
- `engine/indexer/walk.ts`: walk the repo; honor `.gitignore`; skip `node_modules`,
  `dist`, `build`, `.next`, coverage. Classify each file: `server | client | shared | config`.

### Step 2 — Parse layer
- `engine/indexer/parse.ts`: parse with **`ts-morph`** (TS + modern JS). Fallback to
  `@babel/parser` for plain JS with unusual syntax. Return an AST handle + source map.
- Never let one unparseable file abort the run — record it as `unparsed` and continue.

### Step 3 — Extractors (one concern each)
```text
engine/indexer/extractors/
  routes.ts      # app.get/post/put/delete, router.*, method + path + handler ref + inline mw
  middleware.ts  # app.use / router.use / per-route mw arrays → chains
  functions.ts   # fn declarations, params, and CALLS (callee resolution → call graph edges)
  inputs.ts      # req.params / req.query / req.body / req.headers / req.cookies
  mongoose.ts    # Model.find/findOne/findById/update*/delete*/aggregate + collection + query shape
  jwt.ts         # jwt.sign / jwt.verify usage + secret source
  secrets.ts     # process.env.* reads + literals matching secret heuristics
  deps.ts        # package.json dependencies + versions
```
- Resolve handler references so a route knows its handler function node (for C2 CALLS).

### Step 4 — IR model
```ts
interface FileIR {
  path:string; kind:'server'|'client'|'shared'|'config';
  imports:ImportIR[]; functions:FnIR[]; routes:RouteIR[]; middleware:MwIR[];
  inputs:InputIR[]; mongoOps:MongoOpIR[]; jwtOps:JwtOpIR[]; envReads:EnvIR[]; loc:Loc;
}
interface RouteIR { method:string; path:string; handlerFn:string; middleware:string[]; loc:Loc }
interface MongoOpIR { model:string; op:string; queryShape:any; argSources:string[]; loc:Loc }
interface Loc { file:string; line:number; col:number }
```

### Step 5 — Persist + entrypoint
- `engine/indexer/index.ts`: `indexProject(path):Promise<{projectId}>` → writes `projects`
  row (path, gitHead via `simple-git`) + one `files` doc per file with its IR.
- Idempotent: re-indexing the same project updates in place (keyed by projectId+path).

## Pitfalls
- Dynamic route registration (loops, `require`-d route modules) — handle the common
  patterns; flag the rest as `dynamic` rather than silently dropping.
- Middleware order matters — preserve array order in `RouteIR.middleware`.
- Distinguish app-level (`app.use`) from route-level middleware; both feed C2.

## Acceptance / DoD
- On the vulnerable app: IR lists every route (method+path+handler+middleware), every
  Mongoose op with model+op, all deps, all `req.*` inputs, all `process.env` reads.
- Hand-check 5 routes and 5 mongo ops against source — they match, locations correct.
- An intentionally malformed file is marked `unparsed`, run still completes.

## Handoff
C2 consumes `files` IR to build nodes/edges. Guarantee: every route carries its handler
ref and ordered middleware; every mongo op carries its model.

---

## As built / deviations (source of truth for later sessions)

**Verified:** `typecheck`, `lint`, `test` (73 engine tests + dashboard/server) green. Fixture ground truth hand-checked (16 routes, 13 model-resolved
mongo ops, line:col correct e.g. `order.controller.js:4:23` = `Order.findById`). Malformed file → `unparsed`, run completes. Re-run is idempotent.
Smoke on Sentinel-X's own repo: `apps/server` routes `/health`, `/api/config` found; 92 files in ~1.5 s cold. **Not verified:** large real-world MERN repos, class-based controllers, Nest/Fastify (out of scope).

### Decisions (grilled with user)
1. **Test target = in-repo fixture** `packages/engine/test/fixtures/vuln-mern/` (CJS + ESM(.mjs) + TS; seeded IDOR, NoSQLi, mass-assignment, hardcoded JWT secret, safe routes, dynamic registration, broken file, client + test files). Test-only, never shipped. Excluded from tsc/eslint/prettier/vitest.
2. **C1 owns route linking** (see Linker). C2 does no mount/path/middleware resolution.
3. **Extra IR beyond the 8 planned extractors:** `models` (schema fields), `authz` signals, `responses` sinks (+ `exports`, `mounts`, `routers`, `tsconfig`, `envFile`).
4. **Load surface = engine fn + CLI script only** (no REST, no UI, no Docker target mount → C9/C11/C12; mount target `:ro` there).
5. **ts-morph only** (no `@babel/parser`; add if a real file fails). 6. **Client files: classify + record only** (imports via regex, no extraction).
7. New file kind **`test`** (record-only) so test fixtures' fake routes/secrets never reach the graph. Kinds: `server|client|shared|config|test`.

### Layout — `packages/engine/src/indexer/` (subpath export `@sentinelx/engine/indexer`; NOT re-exported from the engine root so the server doesn't load ts-morph at boot)
`types.ts` (all IR) · `walk.ts` (discovery+classify) · `parse.ts` (ts-morph project, syntactic diagnostics) · `context.ts` (`Ctx`: fn ids, scopes, aliases, `srcOf`, `refOf`) ·
`extractors/{imports,functions,routes,inputs,mongoose,jwt,secrets,authz,responses,config}.ts` · `extract.ts` (per-file, pure) · `link.ts` (pure) ·
`analyze.ts` (pure, no DB: walk→extract(reuse by hash)→link) · `index.ts` (persistence + public API).

### Public API (C2/C10/C9 contract)
```ts
indexProject(path, {force?}): Promise<IndexResult>      // idempotent, hash-incremental; emits security_events + bus 'events' {kind:'project.indexed'}
refreshProject(projectId, {force?}): Promise<IndexResult> // = indexProject on the stored path (REPLACES the plan's reindexFiles; hash diff finds changes)
loadProjectIR(projectId): Promise<{project, files: {path,kind,status,ir,linked}[], routes: LinkedRoute[]}>   // C1→C2 contract
analyzeProject(root, prev?) / link(files) / walkProject(root)    // pure helpers (tests, C10)
IndexResult { projectId, root, stats, unparsed[{path,error,line}], changed[], changedLinked[], removed[], durationMs }
```
`changed` = files whose content hash changed/added; `changedLinked` = files whose **linked** view changed (includes files affected by *another* file's change, e.g. removing a global `app.use(authenticate)` marks every routes file) → **C10 uses `changedLinked` to pick the stale set.**
projectId = `sha1(realpath).slice(0,12)`. CLI: `npm run index -- <path> [--dump routes|ops|models|authz|json] [--force]` (root script proxies; path relative to your shell).

### Persistence
`files` unique `{projectId,path}` with `kind, lang, status(indexed|recorded|unparsed|skipped), hash, size, irVersion, ir (raw FileIR), linked (LinkedFile), linkedHash, parseError, parseLine, skipReason`.
`projects` gains `projectId` (unique) + `name, gitHead, gitBranch (null unless root is a git repo root), status(indexing|indexed|failed), stats, indexedAt`.
IR is JSON-normalized before storing (Mongo turns `undefined`→`null`, which broke re-link equality); connection uses `ignoreUndefined`. `$`/`.` keys inside stored IR are fine on Mongo 7.
**Secrets are never stored raw** (`{kind,name,preview:'ab***',len,entropy}`; `.env*` = key names + masked values; jwt literal secrets masked; literals under secret-ish keys masked in `ValueSrc`).

### IR (raw per-file, pure fn of content) — `FileIR`
`imports, exports(+re-exports), routers(app|router, implicit), functions{id,name,parent?,params,calls,traits}, routes(raw registrations), mounts(use() calls),
inputs{fnId,source,path,boundTo}, mongoOps{receiver,op,instance?,queryShape,args,argSources,select?,chain,resultVar?}, models{name,varName,fields[{name,type,ref?,select?,required?,unique?}]},
jwtOps{op,secretSource,algorithms?,expiresIn?,flags}, envReads, secrets, deps{name,range,installed?,dev,pkgPath}, authz, responses, envFile?, tsconfig?, flags`.
- Ids: fn `<file>#<name>` (`#anon@L:C`, `#obj.member`, `#exports.name→name`, `<file>#<module>` = top-level code); route `"METHOD /full/path"` (`#2` on dup). `Loc` = `{file(posix rel), line, col(1-based), endLine?}`.
- `ValueSrc = input{source,path} | authctx{path} | var | literal | object{keys} | spread | call{text,inputs?} | other{text,inputs?}`. Same-scope aliasing (const/never-reassigned let; destructuring; `req.get('x')`; real first-param name, incl. `(err,req,res,next)`); String()/Number()/ObjectId()/toString()/trim() are unwrapped, **any other call is kept as `call` (sanitizers not modeled → N3)**.
- **traits are facts, not policy** (`readsAuthHeader, callsJwtVerify, setsReqUser, sendsAuthError, callsNext, usesReqRes`); C2 decides "auth-like".
- `authz` kinds: `ownership-compare` (incl. `.equals()`, self-access `req.params.id !== req.userId`; `operands{auth,other}`; `guards{status?,action respond|throw|next}` best-effort), `role-check`, `user-scoped-query` (read/update/delete queries filtered by auth ctx; NOT create), `auth-context-read`.
- Handler refs: wrappers unwrapped (`asyncHandler(fn)` → `wrapper:'asyncHandler'`), factories keep args (`requireRole('admin')` → `factory`,`args`).
- Ops/inputs/authz/responses/jwt from closures (e.g. inside `.map(async …)`) attribute to the **handler** (nearest fn owning a `req` param); **CALLS from callbacks stay on the callback fn** (known gap).

### Linker (`link(allFileIR) → {files:{path→LinkedFile}, routes}`), pure
- Own module resolver: relative, `tsconfig/jsconfig` `baseUrl/paths`, `.js→.ts`, `/index.*`; bare specifier = external. Handles `require`, ESM, TS, `export *`/re-exports, `module.exports = {…}`/`exports.x`.
- `LinkedRoute{id,method,path,fullPath,file,router,handlerFnId?,handler,chain[{ref,fnId?,origin app|mount|router|route,mountPath?,conditional?}],mounted,dynamic?,loc}`.
- Order semantics: `use()` applies only to routes registered **after** it and whose path prefix matches (segment-aware; `:param` = wildcard). Mount-statement middleware (`app.use('/admin', requireRole('admin'), adminRouter)`) → `origin:'mount'`. Multi-mounted router → one instance per mount; router never mounted (or `app` param) → `mounted:false`. Dynamic `use()` paths → entry kept with `conditional:true` (never silently asserted/dropped).
- `LinkedFile{imports[{module,resolvedPath?,external}], routes, calls[{…CallIR, fnId, resolved: fn|model|external}], opModels[] (model name per mongoOps index, `collection:x` for raw driver, null if unresolved)}`. Unresolved local calls are dropped; external-package calls kept.

### Known limits (deliberate)
Express only; `router.param()` and class-based controllers (`this.x`) not modeled; regex/computed paths → `dynamic`; no flow-sensitivity or sanitizer modeling; `new Foo()` ops are emitted for any capitalized ctor bound to a variable (C2 must filter by `opModels[i] != null`; `stats.mongoOps` already counts resolved only); client files record imports by regex only.
