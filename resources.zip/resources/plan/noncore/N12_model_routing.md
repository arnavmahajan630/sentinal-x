# N12 — Model Routing / Cost Control

**Type:** Non-core extension · **Tier:** Breadth
**Adds:** cheap model for triage, stronger model for deep investigation; per-scan token budget + spend reporting.
**Why it impresses:** cost-aware engineering.

## Hooks (no core change)
- Sits inside the `engine/llm` provider abstraction + the C5 runtime budget. Agents are unaware.

## Prerequisites
- Core C0 (`LlmProvider`), C5 (runtime budget).

## Build — scaffolding → done
1. Router picks provider/model by task type (fast/cheap for triage & enumeration; stronger for
   deep multi-step investigation).
2. Enforce a per-scan token cap across all agent runs; hard-stop on exhaustion.
3. Report spend per run/scan in the dashboard.

## Acceptance
- A scan stays under the configured token budget; the UI shows per-run and per-scan cost.

## Guardrails
- Routing never downgrades a verification decision — verification is deterministic HTTP, not the LLM.
