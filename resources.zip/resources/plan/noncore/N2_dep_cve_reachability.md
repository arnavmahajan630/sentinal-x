# N2 — Dependency-CVE Reachability

**Type:** Non-core extension · **Tier:** High impact
**Adds:** map `package.json` deps to known CVEs **and** check whether the vulnerable function is
actually reachable in the call graph.
**Why it impresses:** "vulnerable *and reachable*" is exactly what separates this from `npm audit`.
Maps to **OWASP A03 (Software Supply Chain Failures)**.

## Hooks (no core change)
- Reads `engine/facts.getDependency()` + `engine/graph` call graph. Emits standard `Finding`s
  via the C7 model (no exploit needed → confidence from reachability, not verification).

## Prerequisites
- Core C2 (call graph), C3 (deps facts), C7 (Finding model).

> **C2 as-built note:** `Dependency:<pkg>` nodes carry `declared/installed/range/dev/builtin`; `File DEPENDS_ON Dependency` (imports) and `Function CALLS Dependency {calls[{name,line}]}` give the call path to a vulnerable symbol; `Route CALLS Function` → `Function CALLS Function` reach it.

## Build — scaffolding → done
1. Pull advisories from **OSV.dev** (or `npm audit --json`) for installed versions.
2. For advisories with a known vulnerable symbol/entrypoint, search the graph for a `CALLS`
   path from app code to that symbol.
3. Emit findings tagged `reachable: true|false`; only reachable ones escalate severity.
4. Show reachability path in the finding's evidence.

## Acceptance
- A seeded vulnerable dep that is *called* → flagged reachable/High with the call path.
- An installed-but-unused vulnerable dep → flagged unreachable/Low.

## Guardrails
- Reachability via static call graph can miss dynamic requires — mark those `reachable:unknown`
  rather than asserting safe.
