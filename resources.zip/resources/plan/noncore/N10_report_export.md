# N10 — Exportable PDF / Markdown Report

**Type:** Non-core extension · **Tier:** High impact
**Adds:** a pentest-style report export of all findings with evidence chains.
**Why it impresses:** a tangible deliverable faculty can hold; great leave-behind.

## Hooks (no core change)
- Pure output module reading `engine/findings`. A dashboard button + a CLI command.

## Prerequisites
- Core C7 (findings), C11 (dashboard) or C12 (CLI).

## Build — scaffolding → done
1. Report template (Markdown → PDF via `md-to-pdf` / Puppeteer): executive summary, per-finding
   evidence (request/response), severity, affected nodes, attack path, references.
2. `sentinel report --pdf` (CLI) + an "Export" button in the dashboard.
3. Include a scan metadata header (project, commit, date, agent runs).

## Acceptance
- One command/click produces a clean PDF (and Markdown) report of the confirmed findings with
  their evidence chains.

## Guardrails
- Report reflects only verified findings + honest confidence; no speculative content presented
  as confirmed.
