# N13 — Multi-Project Management

**Type:** Non-core extension · **Tier:** Breadth
**Adds:** manage several apps from one dashboard (core loads one project at a time).
**Why it impresses:** platform-grade scope.

## Hooks (no core change)
- `projectId` already scopes every collection — this is mostly a project registry + UI switcher.

## Prerequisites
- Core C11 (dashboard). All engine state is already project-scoped from C1 onward.

## Build — scaffolding → done
1. Project registry (add/remove/list projects) + a dashboard project switcher.
2. Ensure per-project isolation holds across graph, findings, runs, events (audit the queries).
3. Cross-project overview: posture across all loaded apps.

## Acceptance
- Load two apps, switch between them; each keeps an independent graph, findings, and run history;
  no cross-contamination.

## Guardrails
- One active scan/watch per project at a time; don't let schedulers across projects starve each other.
