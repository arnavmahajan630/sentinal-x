# N7 — Active DAST / Endpoint Fuzzing

**Type:** Non-core extension · **Tier:** High wow
**Adds:** autonomous crawling + fuzzing of the running sandbox app, beyond hypothesis-driven
verification.
**Why it impresses:** proactive discovery, not just confirmation.

## Hooks (no core change)
- Lives in the verification layer; **reuses the C7 sandbox guard**. Feeds anomalies back to
  agents as observations for investigation.

## Prerequisites
- Core C7 (guarded client), C9 (orchestrator to route discovered leads to agents).

## Build — scaffolding → done
1. Crawl reachable endpoints from the graph (seeded with known routes).
2. Fuzz params with payload sets (injection, authz, type-confusion); detect anomalies
   (5xx, auth bypass, reflected input, unexpected data).
3. Feed anomalies to agents as observations; agents investigate and request verification.

## Acceptance
- Fuzzing surfaces an endpoint the static pass didn't flag; an agent picks it up and the
  verifier confirms it.

## Guardrails
- **Sandbox-only** via the C7 guard; bounded request rate; global kill switch respected.
- No destructive payloads against stateful endpoints without a reset between runs.
