# N11 — MCP Coding-Agent Interface

**Type:** Non-core extension · **Tier:** Breadth (high demo value)
**Adds:** exposes Sentinel-X as an **MCP server** so Claude Code / Cursor can query it while editing.
**Why it impresses:** the "security infrastructure for agent-assisted development" story — a strong
live demo moment.

## Hooks (no core change)
- Wraps the C3 Fact API + C7 findings behind MCP tools. Read-only over core.

## Prerequisites
- Core C3 (facts), C7 (findings), C9 (to trigger `run_verification`).

## Build — scaffolding → done
1. MCP server exposing tools:
   ```
   security.get_project_state()      security.get_security_findings()
   security.get_endpoint_context()   security.get_attack_surface()
   security.trace_dataflow()         security.check_authorization()
   security.get_security_constraints()  security.run_verification()
   ```
2. Map each to the underlying Fact/Finding/orchestrator call; return structured context.
3. (Optional) proactive warning: on an edit that removes auth middleware, surface a caution.

## Acceptance
- From Cursor/Claude Code: ask *"what security requirements apply to `/orders/:id`?"* → Sentinel-X
  returns structured endpoint context (auth, authorization gaps, dataflow, related findings).

## Guardrails
- `run_verification` still routes through the C7 guard (sandbox-only). MCP exposes read + verify,
  never code modification of the target.
