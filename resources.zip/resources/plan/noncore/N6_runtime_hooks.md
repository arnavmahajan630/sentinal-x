# N6 — Runtime Instrumentation Hooks (live graph)

**Type:** Non-core extension · **Tier:** High wow
**Adds:** a lightweight hook injected into the **sandbox** target (patching Express/Mongoose) to
observe real requests, queries, and auth decisions.
**Why it impresses:** the graph becomes "live" (static + observed) — a genuine differentiator.

## Hooks (no core change)
- Feeds observed edges into `engine/graph` (marked `observed`). Strictly sandbox-only, like the
  verifier — reuse the C7 guard boundary conceptually.

## Prerequisites
- Core C2 (graph), C7 (sandbox discipline), a sandbox target you control.

> **C2 as-built note:** observed edges reuse the static ids (`Route:…`, `Function:…`) with an `observed:true` prop; because `buildGraph` diff-applies a pure static model, keep observed data in a separate overlay (collection or `observed` prop merged at read time) so rebuilds don't erase it.

## Build — scaffolding → done
1. A small instrumentation shim loaded **only** in the sandbox app (env-gated require).
2. Capture: route hits, middleware pass/fail, actual Mongo query objects, auth decisions →
   stream to Sentinel-X over a local channel.
3. Merge observed data with the static graph; tag edges `observed:true`; reconcile mismatches
   (observed route not in static graph → flag).

## Acceptance
- Hitting a route in the sandbox lights up the corresponding graph path live and reveals a
  query the static analysis missed.

## Guardrails
- The shim must never load outside the sandbox (env guard). It observes only; it never blocks or
  modifies target behavior.
