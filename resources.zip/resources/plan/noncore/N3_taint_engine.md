# N3 — Taint / Dataflow Engine (real source→sink)

**Type:** Non-core extension · **Tier:** High wow
**Adds:** true inter-procedural taint tracking (user input → sink) across files and functions,
replacing core's direct-only `FLOWS_TO`.
**Why it impresses:** real static-analysis depth; far fewer false positives/negatives.

## Hooks (no core change)
- Upgrades `FLOWS_TO` edges in `engine/graph` and enriches `facts.getDataflow()`. Same fact
  API surface — agents consume richer paths transparently.

## Prerequisites
- Core C1 (functions/inputs), C2 (graph), C3 (dataflow facts).

> **C2 as-built note:** core FLOWS_TO is `Input→Function` and `Function→Model` (same function; ops in edge props). Taint upgrade adds multi-hop `Function→Function` FLOWS_TO (with `props.tainted|possible`, `sanitizer`) and sink nodes/edges for `res.send`/`eval`/`child_process`; keep the same ids and `getDataflow` shape.

## Build — scaffolding → done
1. Define **sources** (`req.params/query/body/headers/cookies`), **sinks** (Mongo ops,
   `res.send`, `eval`, `child_process`, template render), **sanitizers** (validators, casts).
2. Propagate taint through assignments, function calls (param→return), and object fields
   across files (use the call graph for inter-procedural flow).
3. Enrich the graph with taint-labeled `FLOWS_TO` paths + sanitizer awareness.
4. `getDataflow(inputId)` now returns full source→sink paths with sanitizer status.

## Acceptance
- An input reaching a Mongo query through two helper functions is traced end-to-end.
- Adding a sanitizer on the path clears the taint (flow no longer reported).

## Guardrails
- Precision over recall for the demo — a wrong taint path creates agent false positives.
  Mark uncertain propagation `taint:possible` rather than `tainted`.
