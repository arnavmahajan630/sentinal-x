# N14 — Benchmark Harness (vs Semgrep / CodeQL)

**Type:** Non-core extension · **Tier:** Breadth (high viva value)
**Adds:** a formal evaluation comparing detection rate, false positives, and time against baseline
scanners on the seeded app.
**Why it impresses:** numbers. Faculty respond well to a measured result.

## Hooks (no core change)
- Reads seeded ground truth + `engine/findings`. Standalone harness.

## Prerequisites
- Core C7 (findings) + a seeded target with known ground-truth vulnerabilities.

## Build — scaffolding → done
1. Encode ground truth for the test app: `{ id, type, file, line, exploitable }` per seeded vuln.
2. Run Sentinel-X, Semgrep, and (optionally) CodeQL on the same target; collect their findings.
3. Compute precision / recall / F1 + wall-clock time; map each tool's output to ground truth.
4. Emit a comparison table + chart for the report.

## Acceptance
- A reproducible table showing Sentinel-X's detection rate and false-positive rate vs baselines
  on the identical target, with timings.

## Guardrails
- Fair comparison: same target, same commit, documented tool configs. Report Sentinel-X's misses
  honestly — verified-only precision is the headline.
