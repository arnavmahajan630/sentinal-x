# N8 — Human-in-the-Loop Feedback

**Type:** Non-core extension · **Tier:** Breadth
**Adds:** triage UI to approve, dismiss, or mark findings false-positive; agents learn from feedback.
**Why it impresses:** shows product maturity and a real feedback loop.

## Hooks (no core change)
- Extends `engine/findings` status + the C11 Findings view. Feedback stored and fed back into
  agent context.

## Prerequisites
- Core C7 (findings), C11 (Findings view).

## Build — scaffolding → done
1. Finding actions: **confirm / dismiss / mark-FP** (with reason). Persist to the finding.
2. Feed dismissed patterns back into agent context (a suppression list / lowered confidence) so
   the same pattern doesn't re-flag identically next run.
3. Surface feedback state in the dashboard.

## Acceptance
- Dismissing a finding as false-positive prevents the same pattern from re-flagging on the next
  run (or measurably lowers its confidence).

## Guardrails
- Feedback tunes confidence/suppression only — it never overrides a fresh CONFIRMED exploit
  from C7. Verified reality wins over prior dismissal.
