# N5 — Business-Logic & Race-Condition Detection

**Type:** Non-core extension · **Tier:** High wow
**Adds:** logic flaws (coupon reuse, negative quantity, price tampering) and concurrency issues
(double-spend via parallel requests).
**Why it impresses:** finds bugs pattern scanners fundamentally cannot.

## Hooks (no core change)
- New specialist agent on the C5 runtime + new C7 verification templates. Uses existing graph/facts.

## Prerequisites
- Core C5 (runtime), C7 (verification + findings), a target with stateful flows.

## Build — scaffolding → done
1. Agent reasons over stateful flows (order/payment/coupon/inventory) reconstructed from the graph.
2. New verification templates:
   - **race/double-apply:** fire N parallel requests; assert an invariant break (coupon applied
     twice, balance negative, stock oversold).
   - **logic-tamper:** submit out-of-range values (negative qty, altered price) and check acceptance.
3. Confirmed invariant violations → Findings via C7.

## Acceptance
- Verifier confirms a seeded double-apply-coupon race by firing concurrent requests and
  detecting the broken invariant, with request/response evidence.

## Guardrails
- Concurrency tests run only against the sandbox (C7 guard). Keep parallelism bounded.
- Define invariants explicitly per flow so "violation" is objective, not inferred.
