# N15 — Remediation Guidance (no patching)

**Type:** Non-core extension · **Tier:** High impact
**Adds:** per-finding fix guidance with code snippets — **advice only, never applied.**
**Why it impresses:** closes the loop for developers without breaking the analysis-only rule.

## Hooks (no core change)
- Output-only module reading `engine/findings` + C4 playbooks. Rendered in the C11 Findings view.

> **C4 as-built note:** every vulnerability playbook has a `## Remediation guidance` section (guidance only) — use it as the source text; the finding's playbook `type@version` tells you which one applies. Reference playbooks have none.

## Prerequisites
- Core C7 (findings), C4 (playbooks), C11 (dashboard).

## Build — scaffolding → done
1. For each finding type, generate remediation text + an example snippet derived from the
   playbook (e.g., ownership check for IDOR, input validation for NoSQLi).
2. Show it in the Findings drill-down and (with N10) in the exported report.
3. Never write to the target repo — display/copy only.

## Acceptance
- The IDOR finding shows a correct ownership-check remediation snippet; nothing is written to the
  target codebase.

## Guardrails
- **Hard rule:** analysis-only. Guidance is presented for a human to apply; Sentinel-X never edits
  target code. Keep this line for the viva.
