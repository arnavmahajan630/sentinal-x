# N9 — CVSS 4.0 Scoring

**Type:** Non-core extension · **Tier:** High impact
**Adds:** replaces core's simple severity with full CVSS 4.0 vectors + numeric scores.
**Why it impresses:** industry-standard rigor; clean viva talking point.

## Hooks (no core change)
- Drop-in replacement for `engine/findings/severity.ts` — same interface, richer output
  (`{ severity, cvssVector, cvssScore }`).

## Prerequisites
- Core C7 (Finding model + severity interface).

## Build — scaffolding → done
1. Map finding attributes → CVSS 4.0 base metrics (AV/AC/AT/PR/UI/VC/VI/VA/SC/SI/SA).
2. Compute the vector string + numeric score + qualitative rating.
3. Display vector + score on each finding; keep the simple label as a fallback.

## Acceptance
- The IDOR finding shows a defensible CVSS 4.0 vector and score matching a manual calculation.

## Guardrails
- Derive metrics from actual evidence (exposure, privileges required, impact on
  confidentiality/integrity) — don't inflate scores; keep them justifiable in the viva.
