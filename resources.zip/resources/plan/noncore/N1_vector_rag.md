# N1 — Vector / Embeddings RAG (knowledge upgrade)

**Type:** Non-core extension · **Tier:** High impact
**Adds:** semantic retrieval over playbooks + OWASP/CWE/Express/Mongoose/JWT/Node docs, replacing
core's load-by-type routing with similarity search.
**Why it impresses:** grounded reasoning over a real security corpus, not hardcoded lookups.

## Hooks (no core change)
- Implements the same `engine/knowledge` interface: `getPlaybooksForSignals()` / a new
  `retrieve(query,k)`. Swap the implementation; core keeps its deterministic fallback.

> **C4 as-built note:** the swap point is `KnowledgeRegistry` (`getPlaybooksForSignals`, `getPlaybook`, `listPlaybooks`, `matchPlaybooks`). Playbooks are chunkable by their fixed `## ` sections; `security_knowledge` already stores body + hash/version for re-embedding on change. Keep signal routing as the deterministic fallback.

## Prerequisites
- Core C4 (playbook loader) + C0 (`LlmProvider` for embeddings).

## Build — scaffolding → done
1. Ingest docs + playbooks → chunk (headed sections) → embed (Gemini embeddings or local
   `bge-small`).
2. Store vectors in **MongoDB Atlas Vector Search** (stays MERN) or a local store (LanceDB/Chroma).
3. `retrieve(query,k)` → top-k chunks with source refs; agents cite retrieved passages.
4. Keep load-by-type as a deterministic fallback when retrieval confidence is low.

## Acceptance
- An agent investigating a route retrieves the right playbook passages by meaning (not exact
  type) and cites them in its reasoning trace.

## Guardrails
- Retrieval augments, never replaces, the fact-grounded signals — a citation is not evidence;
  only C7 confirms.
