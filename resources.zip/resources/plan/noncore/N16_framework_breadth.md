# N16 — Framework Breadth (NestJS / Fastify / Next.js)

**Type:** Non-core extension · **Tier:** Breadth
**Adds:** support beyond Express-MERN — NestJS, Fastify, and Next.js API routes.
**Why it impresses:** handles "production-grade" apps that aren't vanilla Express.

## Hooks (no core change)
- Adds framework-specific extractors to `engine/indexer/extractors`. They normalize into the
  **same IR route/middleware shape**, so the graph, facts, and agents are untouched.

## Prerequisites
- Core C1 (indexer extractor pattern), C2 (graph consumes normalized IR).

> **C1 as-built note:** framework extractors must emit the same raw IR **including `routers`, `routes`, `mounts` (with `order`), `exports`, `functions`** so the C1 linker composes paths/chains unchanged. Nest guards/Fastify `preHandler` → `RouteIR.middleware` or `MountIR.args`; Next.js file-based routes → routes with literal `path` on an implicit `app` router marked mounted (add an explicit router decl with `kind:'app'`, `implicit` unset).

## Build — scaffolding → done
1. NestJS: parse decorators (`@Controller`, `@Get/@Post`, `@UseGuards`, `@Injectable`) → routes +
   guard chains.
2. Fastify: parse `fastify.route`/`.get/.post` + `preHandler` hooks → routes + middleware.
3. Next.js: parse `app/api/**/route.ts` handlers + `middleware.ts` → routes + protection.
4. Emit identical `RouteIR`/`MwIR` so nothing downstream changes.

## Acceptance
- Point Sentinel-X at a Next.js API-routes app; routes and guards appear in the graph and the
  Auth agent runs with **no changes** to agents or verification.

## Guardrails
- Keep normalization strict — if a framework's protection model can't be mapped confidently,
  mark routes `authorization:'unknown'` rather than guessing `present`.
