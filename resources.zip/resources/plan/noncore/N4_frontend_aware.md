# N4 — Frontend-Aware Analysis

**Type:** Non-core extension · **Tier:** Breadth
**Adds:** React-side security — map client API calls → backend routes, token storage
(localStorage vs httpOnly cookie), client-only auth checks, XSS surfaces.
**Why it impresses:** a full-stack security view; strong MERN fit and rare in student projects.

## Hooks (no core change)
- Adds client extractors to `engine/indexer` and new node types (`ClientCall`, `TokenStore`)
  + edges; feeds new signals to the Auth/Dataflow agents via existing facts.

## Prerequisites
- Core C1 (indexer), C2 (graph), C6/C8 (agents).

> **C2 as-built note:** new node types must use deterministic ids (`ClientCall:<file>#<name>@L:C`, `TokenStore:<file>:<line>`) so `buildGraphModel` diff-apply keeps them stable; add them in a separate pure pass merged into the model (not by mutating stored graph).

## Build — scaffolding → done
1. Extract `fetch`/`axios` calls in React → resolve URL/method → edge
   `ClientCall EXPOSES Route` (link client call to backend route).
2. Detect token storage location (localStorage/sessionStorage vs httpOnly cookie) → `TokenStore` node.
3. Detect client-side-only guards (auth checks that exist only in React).
4. Flag XSS surfaces: `dangerouslySetInnerHTML`, unsanitized `href`/`src`.

## Acceptance
- Dashboard shows which React call hits the vulnerable route.
- Flags a token stored in localStorage and a client-only admin guard (server unprotected).

## Guardrails
- Client-only auth is a *signal*, not proof — the server-side verification (C7) still decides.
